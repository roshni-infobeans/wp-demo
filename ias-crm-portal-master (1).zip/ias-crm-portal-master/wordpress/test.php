<?php
if ( ! defined( 'ABSPATH' ) ) {
    /** Set up WordPress environment */
    require_once( dirname( __FILE__ ) . '/wp-load.php' );
    require_once( dirname( __FILE__ ) . '/wp-content/plugins/crm-connector/document_upload_cron.php' );
    require_once( dirname( __FILE__ ) . '/wp-content/plugins/crm-connector/create_closed_activity_cron.php' );
    require_once( dirname( __FILE__ ) . '/wp-content/plugins/ib-gp-integration/ib-gp-integration.php' );
    
} else {
    echo "Unable to load wordpress";
    die;
}
global $wpdb;
testGPPushwithDummyData();
exit;
require_once( dirname( __FILE__ ) . '/wp-content/plugins/ib-general-function/ib-general-function.php' );
//generate_portal_checklist_mapping();
//exit;
echo '<pre>';
$crmOperationsObj = getCrmConnection();
$leadObj = $crmOperationsObj->getEntityObj( 'contact' );
//print_r($leadObj); exit;
//$leadObj->ID = '60adba37-a7c3-eb11-b81a-0050569d3a1e';
//$leadObj->firstname = 'FirstName';
//$leadObj->lastname = 'LastName';
//$leadObj->companyname = 'COmpanyName';
//$leadObj->websiteurl = $postParam['websiteurl'];
//$leadObj->address1_city = 'address1_city';
//$leadObj->address1_postalcode = 3456;
//$leadObj->address1_line1 = 'address1_line1';
//$statuscode = $crmOperationsObj->get_entity_status_code_by_entity_name( "lead", "statuscode");
//print_r($statuscode);
//exit;
try{
    //$crmOperationsObj->updateEntity($leadObj);
    $where = array( 'type' => 'and' );
    $where['conditions'][] = array( 'attribute' => 'emailaddress1', 'operator' => 'eq', 'value' => 'quoteedit2@yopmail.com' );
    $resultData = $crmOperationsObj->getCrmEntityDetails( 'contact', $where, 'list', '', 1, 10 );
    print_r($resultData);
} catch ( Exception $e ) {
    print_r($e);
}
exit;
//$a['new_labstateid'] = 109;
//$a['new_stateid'] = 109;
//$a = json_encode($a);
//$records = $wpdb->get_results("select * from wp_application_data where state = 109 or application_data like '%".$a."%'");
//echo '<pre>';
//echo $wpdb->last_query;
//print_r($records);
//exit;
foreach($records as $rec){
    $options = [];
    $options['quote_id'] = $rec->id;
    $options['crm_id'] = $rec->crm_id;
    $options['status'] = $rec->status;
    print_r($options);
    closeQuote2($options);
}

function closeQuote2($options) {
    global $wpdb;
    if ( ! empty( $options['quote_id'] ) && $options['quote_id'] > 0 ) {
    $updated = false;
    $crmId = $options['crm_id'];
    if( ! empty( $crmId ) ) {
        $crmOperationsObj = getCrmConnection();
        $leadObj = $crmOperationsObj->getEntityObj( 'lead' );
        $leadObj->ID = $crmId;
        //$statuscode = $crmOperationsObj->get_entity_status_code_by_entity_name( "lead", "statuscode");
        //$statecode = $crmOperationsObj->get_entity_status_code_by_entity_name( "lead", "statecode");
        //print_r($statuscode);
        //print_r($statecode);
        //exit;
        //$statecode = $crmOperationsObj->get_entity_status_code_by_entity_name( "lead", "statecode", "Disqualified" );
        //$statuscode = $crmOperationsObj->get_entity_status_code_by_entity_name( "lead", "statuscode", "Canceled" );
        if( 'Closed' == $options['status'] ) {
            $statecode = $crmOperationsObj->get_entity_status_code_by_entity_name( "lead", "statecode", "Open" );
            $statuscode = $crmOperationsObj->get_entity_status_code_by_entity_name( "lead", "statuscode", "New" );
        }
        $leadObj->address1_stateorprovince = '9a2793b2-56e2-ea11-8101-005056bd15cd';

        try{
            if( 'Closed' == $options['status'] ) {
                $crmOperationsObj->crmConnector->setState( $leadObj, $statecode, $statuscode );
                $statecode = $crmOperationsObj->get_entity_status_code_by_entity_name( "lead", "statecode", "Disqualified" );
                $statuscode = $crmOperationsObj->get_entity_status_code_by_entity_name( "lead", "statuscode", "Canceled" );
                $crmOperationsObj->crmConnector->setState( $leadObj, $statecode, $statuscode );
            }
            $crmOperationsObj->updateEntity($leadObj);
        } catch ( Exception $e ) {
            print_r($e);
        }
    }
    $updated = $wpdb->update(
            "{$wpdb->prefix}quotation_program", array(
                    'status'      => 'Closed',
                    'address1_stateorprovince' => 629,
                    'modified_by' => get_current_user_id(),
                    'modified_on' => date( 'Y-m-d H:i:s' ),
            ), array( 'id' => $options['quote_id'] )
    );
    if ( $updated ) {
        echo 'Quotation request closed successfully<br>';
    }
}
}