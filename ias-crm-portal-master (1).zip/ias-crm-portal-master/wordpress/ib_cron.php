<?php

$page = isset( $_REQUEST['page'] ) ? $_REQUEST['page'] : '';

global $cron_output;
$cron_output = 1;
if ( isset( $argv[1] ) ) {
	$page = $argv[1];
	$cron_output = 0;
}
$boolByLastCronDate = true;
if ( isset( $argv[2] ) ) {
	$boolByLastCronDate = $argv[2];
}
$quotation_id = 0;
if ( (isset( $argv[2] ) && ! empty( $argv[2] )) && ($argv[1] == 'quotation') ) {
	$quotation_id = $argv[2];
}
ignore_user_abort( true );

if ( ! empty( $_POST ) || defined( 'DOING_AJAX' ) || defined( 'DOING_CRON' ) ) {
	die();
}

// define('DOING_CRON', true);

$default_execution_time = ini_get( 'max_execution_time' );
ini_set( 'max_execution_time', 0 ); //0=NOLIMIT

$default_error_reporting = ini_get( 'error_reporting' );
ini_set( 'error_reporting', E_ALL );

ini_set( 'memory_limit', '-1' );

set_time_limit( 400 );

if ( ! defined( 'ABSPATH' ) ) {
	/** Set up WordPress environment */
	require_once( dirname( __FILE__ ) . '/wp-load.php' );
	require_once( dirname( __FILE__ ) . '/wp-content/plugins/crm-connector/document_upload_cron.php' );
	require_once( dirname( __FILE__ ) . '/wp-content/plugins/crm-connector/create_closed_activity_cron.php' );
} else {
	echo "Unable to load wordpress";
	die;
}
if ( ! isset( $_SERVER['HTTP_HOST'] ) or empty( $_SERVER['HTTP_HOST'] ) ) {
	$_url = explode( '//', get_option( 'siteurl' ) )[1];
}
if ( ! defined( 'WP_HOME' ) ) {
	define( 'WP_HOME', 'http://' . (isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : $_url) . '/' );
}

/** Setting FromName in php mailer after initialization * */
add_action( 'phpmailer_init', 'ib_phpmailer_set_from_name' );

function ib_phpmailer_set_from_name( $phpmailer ) {
	$phpmailer->isSMTP();
	$from_name = get_option( 'mail_from_name' );
	$from_email = get_option( 'mail_from' );
	$phpmailer->FromName = $from_name;
	$phpmailer->From = $from_email;
}

switch ( $page ) {

	case 'quotation':
            	$id = insert_cron_log( $page );
		if ( isset( $_REQUEST['quotation_id'] ) ) {
			$quotation_id = $_REQUEST['quotation_id'];
		}
		ob_start();
		$results = do_shortcode( "[wp-crm-cron quotation_id=" . $quotation_id . "]" );
		$ob_contents = ob_get_contents();
		ob_end_flush();
		$ob_contents_arr = json_decode( $ob_contents, true );
		log_cron_execution_results( $ob_contents_arr, "crm_cron" );
		update_cron_log( $id );
		break;
	case 'application':
		$id = insert_cron_log( $page );
		ob_start();
		$results = do_shortcode( "[wp-application-cron]" );
		$ob_contents = ob_get_contents();
		ob_end_flush();
		$ob_contents_arr = json_decode( $ob_contents, true );
		log_cron_execution_results( $ob_contents_arr, "application_cron" );
		update_cron_log( $id );
		break;
	case 'locationmaster':
		$id = insert_cron_log( $page );
		state_insert();
		country_insert();
		update_cron_log( $id );
		break;
	case 'documentupload':
		$id = insert_cron_log( $page );
		if ( (isset( $argv[2] ) && ! empty( $argv[2] )) && ($argv[2] == 'assessor-profile') ) {
			assessor_upload_document( 'assessor_profile' );
		} else {
			document_upload_cron();
		}
		update_cron_log( $id );
		break;
	case 'application_renewal_notification':
		$id = insert_cron_log( $page );
		ob_start();
		$results = do_shortcode( "[wp-application-renewal-notification-cron]" );
		$ob_contents = ob_get_contents();
		ob_end_flush();
		$ob_contents_arr = json_decode( $ob_contents, true );
		//Used to retrieve application data by crm id for to be renewed application whose application_data is blank.
		//fetch_application_via_crm_id();
		log_cron_execution_results( $ob_contents_arr, "application_renewal_notification" );
		update_cron_log( $id );
		break;
	case 'push_notification_reminder':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/ias-fcm-notifications/ias-fcm-pn-cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/ias-fcm-notifications/ias-fcm-pn-cron.php';
			$ias_pn_cron_obj = new IasFcmPnCron();
			$ias_pn_cron_obj->send_reminder();
		} else {
			die( "File not found: ias-fcm-pn-cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'push_notification_token_expiration':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/ias-fcm-notifications/ias-fcm-pn-cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/ias-fcm-notifications/ias-fcm-pn-cron.php';
			$ias_pn_cron_obj = new IasFcmPnCron();
			$ias_pn_cron_obj->expire_push_notification_token();
		} else {
			die( "File not found: ias-fcm-pn-cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'pullcustomer':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pullCrmEntity( 'account', 1, 2500, $boolByLastCronDate );
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'pullcontact':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pullCrmEntity( 'contact', 1, 2500, $boolByLastCronDate );
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'newapplication':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pullCrmEntity( 'new_application', 1, 2500, $boolByLastCronDate );
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'newcertificate':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pullCrmEntity( 'new_certificate', 1, 2500, $boolByLastCronDate );
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'sync_closed_leads':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pullCrmEntity( 'lead', 1, 2500, $boolByLastCronDate );
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'certificate_renewal_fee':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pullCrmEntity( 'quote', 1, 2500, $boolByLastCronDate );
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'pullfromcrm':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pullAllEntities( $boolByLastCronDate );
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'sendmailtocontacts':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/sendMailToCRMPulledContacts.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/sendMailToCRMPulledContacts.php';

			$objSendMail = new sendMailToContacts();
			$objSendMail->sendMailToPulledContacts();
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'application_fetch_via_crm_id' :
		$id = insert_cron_log( $page );
		fetch_application_via_crm_id();
		update_cron_log( $id );
		break;
	case 'pushlead':
		$id = insert_cron_log( $page );
		if ( isset( $_REQUEST['quotation_id'] ) ) {
			$quotation_id = $_REQUEST['quotation_id'];
		}
		ob_start();
		$results = do_shortcode( "[wp-push-lead-cron quotation_id=" . $quotation_id . "]" );
		$ob_contents = ob_get_contents();
		ob_end_flush();
		$ob_contents_arr = json_decode( $ob_contents, true );
		log_cron_execution_results( $ob_contents_arr, "push_lead_cron" );
		update_cron_log( $id );
		break;
	case 'pushlead_pending':
		$id = insert_cron_log( $page );
		$tablename = $wpdb->prefix . 'quotation_program ';
		$results = $wpdb->get_results( $wpdb->prepare( "SELECT id FROM " . $tablename . " where status=%s and crm_id is NULL and created_date <= '".date('Y-m-d H:i:s', strtotime( '5 minutes ago' ))."'", 'New' ) );
		foreach ( $results as $result ) {
			if ( isset( $result->id ) ) {
				$_REQUEST['quotation_id'] = $quotation_id = $result->id;
			}
			ob_start();
			$results = do_shortcode( "[wp-push-lead-cron quotation_id=" . $quotation_id . "]" );
			$ob_contents = ob_get_contents();
			ob_end_flush();
			$ob_contents_arr = json_decode( $ob_contents, true );
			log_cron_execution_results( $ob_contents_arr, "push_lead_cron" );
		}
		update_cron_log( $id );
		break;
	case 'create_closed_activity':
		$id = insert_cron_log( $page );
		$application_id = '';
		if ( isset( $_REQUEST['application_id'] ) ) {
			$application_id = $_REQUEST['application_id'];
		}
		create_closed_activity( $application_id );
		update_cron_log( $id );
		break;
	case 'invoice_pull_from_crm':
		$id = insert_cron_log( $page );
		invoice_pull_from_crm();
		update_cron_log( $id );
		break;
	case 'pull_staff_from_crm':
		$id = insert_cron_log( $page );
		pull_staff_from_crm();
		update_cron_log( $id );
		break;
        case 'pull_staff_for_admin' :
            pullStaffForAdmin();
            break;
	case 'pull_assessment_from_crm':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pull_assessment_from_crm();
		}
		update_cron_log( $id );
		break;
	case 'delete_lead_from_crm':
		$id = insert_cron_log( $page );
		$mm = $dd = $yyyy = null;
		if ( isset( $argv[2] ) ) {
			$dd = intval( $argv[2] );
		}
		if ( isset( $argv[3] ) ) {
			$mm = intval( $argv[3] );
		}
		if ( isset( $argv[4] ) ) {
			$yyyy = intval( $argv[4] );
		}
		if ( (isset( $dd ) && ( ! empty( $dd )) && ($dd > 0)) && (isset( $mm ) && ( ! empty( $dd )) && ($dd > 0)) && (isset( $yyyy ) && ( ! empty( $yyyy )) && ($yyyy > 0)) ) {
			delete_all_lead_from_crm_by_created_date( $dd, $mm, $yyyy );
		} else {
			echo "Invalid deletion date parameters please enter date in dd mm yyyy format then run this script from command line";
			exit( 0 );
		}
		update_cron_log( $id );
		break;
	case 'gp_push':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/ib-gp-integration/ib_gp_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/ib-gp-integration/ib_gp_cron.php';
			$gp_cron = new ib_gp_cron();
			$gp_cron->push_to_gp();
		} else {
			die( "File not found: ib_gp_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'gp_status_check':
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/ib-gp-integration/ib_gp_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/ib-gp-integration/ib_gp_cron.php';
			$gp_cron = new ib_gp_cron();
			$gp_cron->check_gp_status();
		} else {
			die( "File not found: ib_gp_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'send_quarterly_renewal_mail':
		$id = insert_cron_log( $page );
		//send_quarterly_renewal_mail_to_staff
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/quarterly_renewal_mail_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/quarterly_renewal_mail_cron.php';
			$quarterly_renewal_notification = new quarterly_renewal_notification();
			$quarterly_renewal_notification->run();
		} else {
			die( "File not found: quarterly_renewal_mail_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'send_welcome_mail':
		$id = insert_cron_log( $page );
		send_welcome_mail();
		update_cron_log( $id );
		break;
	case 'fetch_crm_certificates_contact_mapping':
		$id = insert_cron_log( $page );
		fetch_crm_certificates_contact_mapping();
		update_cron_log( $id );
		break;
	case 'payment_status_update':
		$id = insert_cron_log( $page );
		do_action( 'update_failed_payment' );
		update_cron_log( $id );
		break;
	case 'pullassessor':
		$id = insert_cron_log( $page );

		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pullCrmEntity( 'equipment', 1, 2500, $boolByLastCronDate );
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'appointment';
		$id = insert_cron_log( $page );
		if ( file_exists( WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php' ) ) {
			require_once WP_PLUGIN_DIR . '/crm-connector/pull_crm_data_cron.php';
			$obj_pull_crm_data = new pullCrmData();
			$obj_pull_crm_data->pullCrmEntity( 'serviceappointment', 1, 25, $boolByLastCronDate );
		} else {
			die( "File not found: pull_crm_data_cron.php" );
		}
		update_cron_log( $id );
		break;
	case 'send_reminder_for_expense_sheet':
		if ( file_exists( WP_PLUGIN_DIR . '/ib-assessor-manager/notification/AssessorManagementNotifications.php' ) ) {
			require_once WP_PLUGIN_DIR . '/ib-assessor-manager/notification/AssessorManagementNotifications.php';
			$objSendMail = new AssessorManagementNotifications();
			$objSendMail->SendReminderToSubmitExpenseSheet();
		} else {
			die( "File not found: AssessorManagementNotifications.php" );
		}
		break;
	case 'reminder_to_lead_assessor':
		if ( class_exists( 'AgendaCron' ) ) {
			$AgendaCron = new AgendaCron();
			$AgendaCron->notifyLeadToSendAgend();
		}
		break;
	case 'assesment_status_update_cron':
		if ( class_exists( 'AssesmentStatusUpdateCron' ) ) {
			$AssesmentStatusUpdateCron = new AssesmentStatusUpdateCron();
			$AssesmentStatusUpdateCron->updateAssessmentStatus();
		}
		break;
	case 'sendEmailToAssessorForChecklist':
		if ( class_exists( 'SendEmailToAssessorForChecklist' ) ) {
			$SendEmailToAssessorForChecklist = new SendEmailToAssessorForChecklist();
			$SendEmailToAssessorForChecklist->sendEmailToAssessor();
		}
		break;
	case 'unresolved_car_reminder':
		unresolved_car_reminder();
		break;
	case 'assign_staff':
		assign_staff();
		break;
	case 'staff_notification_association';
		staff_notification_association();
		break;
	case 'reminder_to_acknowledge_assessment_assignment':
		reminder_to_acknowledge_assessment_assignment();
		break;

        case 'testme':
            global $wpdb;
            $quotations = $wpdb->get_results( "select "
            . "qp.quote_id, qp.status, c.name as company, "
            . "qp.firstname, qp.lastname, "
            . "CONCAT(qp.firstname, ' ', qp.lastname) as created_by, qp.amount,"
            . "qp.emailaddress1, qp.created_date , qp.companyname, "
            . "p.name as program, qp.address1_city as city, st.fullname, ct.country, "
            . "qp.telephone1 as phone, lg.created_on as sent_on, pmt.created_on as applied_on, apd.id as apd_id, concat(qp.address1_line1,', \t',qp.address1_postalcode) as address, "
            . "IF(qp.status = 'Qualified' and qp.crm_id IS NULL,'Yes','No') AS `Existing Customer`, qp.crm_id "
            . " FROM wp_quotation_program AS qp "
            . " LEFT JOIN wp_company AS c ON c.id = qp.company_id "
            . " LEFT JOIN wp_state AS st ON st.id = qp.address1_stateorprovince "
            . " LEFT JOIN wp_country ct ON ct.id = qp.address1_country "
            . " LEFT JOIN wp_programs AS p ON p.id = qp.program_id "
            . " LEFT JOIN wp_logger AS lg ON lg.ref_id = qp.id AND lg.ref_type = 'sent_quotation' "
            . " LEFT JOIN wp_application_data AS apd ON apd.quotation_id = qp.id and apd.status != 'Draft' and apd.id is not null "
            . " LEFT JOIN wp_payment AS pmt ON apd.id = pmt.application_id "
            . " WHERE qp.created_date BETWEEN '2020-01-01 00:00:01' AND '2020-06-25 23:59:00'  GROUP BY qp.emailaddress1 " );
            print_r($wpdb->last_query);
            echo "<table><tbody><tr>"
            . "<th>Quote Id</th>"
            . "<th>Program</th>"
            . "<th>Status</th>"
            . "<th>Company</th>"
            . "<th>First Name</th>"
            . "<th>Last Name</th>"
            . "<th>Full Name</th>"
            . "<th>Email</th>"
            . "<th>Address</th>"
            . "<th>City</th>"
            . "<th>State</th>"
            . "<th>Country</th>"
            . "<th>Phone</th>"
            . "<th>Amount</th>"
            . "<th>Requested on</th>"
            . "<th>Sent on</th>"
            . "<th>Applied on</th>"
            . "</tr>";
            foreach ( $quotations as $quote ) {
                $applied_on = $sent_on = 'NA';
                $sent_on = ( ! empty( $quote->sent_on )) ? get_formated_date( $quote->sent_on ) : 'NA';
                $applied_on = ( ! empty( $quote->applied_on )) ? get_formated_date( $quote->applied_on ) : 'NA';
                echo "<tr>"
                . "<td>{$quote->quote_id}</td>"
                . "<td>{$quote->program}</td>"
                . "<td>{$quote->status}</td>"
                . "<td>{$quote->companyname}</td>"
                . "<td>{$quote->firstname}</td>"
                . "<td>{$quote->lastname}</td>"
                . "<td>{$quote->created_by}</td>"
                . "<td>{$quote->emailaddress1}</td>"
                . "<td>{$quote->address}</td>"
                . "<td>{$quote->city}</td>"
                . "<td>{$quote->fullname}</td>"
                . "<td>{$quote->country}</td>"
                . "<td>  {$quote->phone}</td>"
                . "<td>{$quote->amount}</td>"
                . "<td>" . get_formated_date( $quote->created_date ) . "</td>"
                . "<td>$sent_on</td>"
                . "<td>$applied_on</td>"
                . "</tr>";
            }
            echo "</tbody></table>";
            die;
            break;

}

/**
 * Used to log messages in log file after executing script, Note:currently only error/failure messages were logged in log file
 * @param array $results, to log messages
 * @param string $script_name, used to generate/retrieve error log file to load error messages
 */
function log_cron_execution_results( $results = array(), $script_name = "crm_cron" ) {
	global $default_execution_time;
	global $default_error_reporting;
	if ( is_array( $results ) && (count( $results ) > 0) ) {
		$log_dir = dirname( __FILE__ ) . DIRECTORY_SEPARATOR . "cron_logs";
		$log_file_name = $script_name . "_logs.txt";
		$log_file_path = $log_dir . DIRECTORY_SEPARATOR . $log_file_name;
		if ( ! file_exists( $log_dir ) ) {
			if ( ! mkdir( $log_dir, 0744 ) ) {
				syslog( LOG_ERR, "[" . date( 'Y-m-d H:i:s', time() ) . "]Unable to generate log directory for cron logs." );
				ini_set( 'max_execution_time', $default_execution_time );
				ini_set( 'error_reporting', $default_error_reporting );
				exit( 1 );
			}
		}
		$fp = @fopen( $log_file_path, "a" );
		if ( ! $fp ) {
			syslog( LOG_ERR, "[" . date( 'Y-m-d H:i:s', time() ) . "]Unable to generate log file for cron logs in cron directory." );
			ini_set( 'max_execution_time', $default_execution_time );
			ini_set( 'error_reporting', $default_error_reporting );
			exit( 1 );
		}
		switch ( $script_name ) {
			case 'crm_cron':
				foreach ( $results as $result_key => $result ) {
					if ( (is_array( $result )) && (count( $result ) > 0) ) {
						foreach ( $result as $message_key => $messages ) {
							if ( ($message_key == 'result') && ($messages[0] == 'error') ) {
								fwrite( $fp, "[" . date( 'Y-m-d H:i:s', time() ) . "]Error: Error for processing quotation having quotation_id:" . $result_key . "\r\n" );
								foreach ( $result['messages'] as $msg ) {
									fwrite( $fp, "[" . date( 'Y-m-d H:i:s', time() ) . "]Error Details: " . $msg . "\r\n" );
								}
							}
						}
					}
				}
				break;
			case 'application_cron':
				foreach ( $results as $result_key => $result ) {
					if ( (is_array( $result )) && (count( $result ) > 0) ) {
						foreach ( $result as $message_key => $messages ) {
							if ( ($message_key == 'result') && ($messages[0] == 'error') ) {
								fwrite( $fp, "[" . date( 'Y-m-d H:i:s', time() ) . "]Error: Error for processing application having id:" . $result_key . "\r\n" );
								foreach ( $result['messages'] as $msg ) {
									fwrite( $fp, "[" . date( 'Y-m-d H:i:s', time() ) . "]Error Details: " . $msg . "\r\n" );
								}
							}
						}
					}
				}
				break;
			case 'application_renewal_notification':
				foreach ( $results as $result_key => $result ) {
					if ( (is_array( $result )) && (count( $result ) > 0) ) {
						//Log success messages as well to check issue 0000538
						foreach ( $result as $message_key => $messages ) {
							if ( $message_key == 'result' ) {
								fwrite( $fp, "[" . date( 'Y-m-d H:i:s', time() ) . "]Renewal email notification send for application having ID:" . $result_key . "\r\n" );
								foreach ( $result['messages'] as $msg ) {
									fwrite( $fp, "[" . date( 'Y-m-d H:i:s', time() ) . "]: " . $msg . "\r\n" );
								}
							}
						}
					}
				}
				break;
		}
		fclose( $fp );
	}
}

function state_insert() {
    global $cron_output;
    global $wpdb;
    $result_messages = array();
    $log_messages = array();
    $start = 1;
    $limit = 1000;
    $CrmOperationsobj = getCrmConnection();
    $result = $wpdb->get_results( $wpdb->prepare( "select * from " . $wpdb->prefix . "state WHERE %d", 1 ) );
    for ( $j = 0; $j < count( $result ); $j ++ ) {
        $state_data[$result[$j]->crm_id] = $result[$j];
    }

    do {
        $resultsfromcrm = $CrmOperationsobj->getCrmEntityDetails( 'new_state', array( 'type' => 'and', 'conditions' => array( array( 'attribute' => 'statecode', 'operator' => 'eq', 'value' => 'Active' ) ) ), 'list', null, $start, $limit );
        //echo '<pre>';print_r($resultsfromcrm->Entities);
        //exit;
        $stateinsertsql = "";
        $deleteStateID = "";
        $deleteStateSql = ' delete from ' . $wpdb->prefix . 'state where crm_id not in (';
        $i = 1;
        try {
            foreach ( $resultsfromcrm->Entities as $stateresult ) {
                if ( isset( $state_data[$stateresult->new_stateid]->crm_id ) && $state_data[$stateresult->new_stateid]->crm_id == $stateresult->new_stateid ) {
                    $country_id = isset( $stateresult->new_country ) ? $stateresult->new_country->Value->Id : '' ;
                    if ( ($state_data[$stateresult->new_stateid]->state != $stateresult->new_name || $state_data[$stateresult->new_stateid]->fullname != $stateresult->new_fullname || $state_data[$stateresult->new_stateid]->country_id != $country_id ) && ($state_data[$stateresult->new_stateid]->crm_id == $stateresult->new_stateid) ) {

                        $stateupdatesql = $wpdb->prepare("UPDATE {$wpdb->prefix}state SET  `state` = %s, `fullname` = %s, `country_id` = %s WHERE crm_id = %s", addslashes( $stateresult->new_name ), addslashes( $stateresult->new_fullname ), $country_id, $stateresult->new_stateid );
                        $state_update_result = $wpdb->query( $stateupdatesql );
                        if ( $state_update_result instanceof WP_Error ) {
                            $result_messages[$stateresult->new_name]['messages'][] = __( 'Unable to update data in portal for state having portal name' ) . ":" . $stateresult->new_name;
                            $result_messages[$stateresult->new_name]['result'][] = "error";
                        } else {
                            $result_messages[$stateresult->new_name]['messages'][] = __( 'Data updated successfully for state having portal name' ) . ":" . $stateresult->new_name;
                            $result_messages[$stateresult->new_name]['result'][] = "success";
                        }
                    }
                } else {
                    $country_id = isset( $stateresult->new_country ) ? $stateresult->new_country->Value->Id : '' ;
                    $stateinsertsql = $wpdb->prepare("INSERT INTO {$wpdb->prefix}state (`state`,`crm_id`, `country_id`, `fullname`) values (%s, %s, %s, %s)", addslashes( $stateresult->new_name ), $stateresult->new_stateid, $country_id, $stateresult->new_fullname );
                    $state_insert_result = $wpdb->query( $stateinsertsql );
                    if ( $state_insert_result instanceof WP_Error ) {
                        $result_messages[$stateresult->new_name]['messages'][] = __( 'Unable to insert data in portal for state having portal name' ) . ":" . $stateresult->new_name;
                        $result_messages[$stateresult->new_name]['result'][] = "error";
                    } else {
                        $result_messages[$stateresult->new_name]['messages'][] = __( 'Data inserted successfully for state having portal name' ) . ":" . $stateresult->new_name;
                        $result_messages[$stateresult->new_name]['result'][] = "success";
                    }
                }
                if ( $i != 1 ) {
                    $deleteStateID .= ",'" . $stateresult->new_stateid . "'";
                } else {
                    $deleteStateID .= "'" . $stateresult->new_stateid . "'";
                }
                $i ++;
            }
        } catch ( Exception $e ) {
            if ( $cron_output ) {
                $result_messages[$stateresult->new_name]['result'][0] = "error";
                $result_messages[$stateresult->new_name]['messages'][] = "Error Code:" . $e->getCode() . ", Error Line:" . $e->getLine() . ", Error Message:" . $e->getMessage() . ", country having portal name :" . $stateresult->new_name;
            }
        }
        if ( $cron_output && ! empty( $result_messages ) ) {
            echo json_encode( $result_messages );
        } else {
            $log_messages['0']['result'][0] = "notice";
            $log_messages['0']['messages'][] = __( 'No State found for update or insert' );
            if ( $cron_output && ! empty( $log_messages ) ) {
                echo json_encode( $log_messages );
            }
        }
        $deleteStateSql .= $deleteStateID . ")";
        if ( isset( $deleteStateID ) && $deleteStateID != '' ) {
            $wpdb->query( $deleteStateSql );
        }
        $start ++;
    } while ( $resultsfromcrm->MoreRecords == 1 );
}

function country_insert() {
    global $wpdb;
    global $cron_output;
    $start = 1;
    $limit = 1000;
    $result_messages = array();
    $log_messages = array();
    $CrmOperationsobj = getCrmConnection();
    $country_data = $wpdb->get_results( $wpdb->prepare( "select LOWER(crm_id) as crm_id, id, country from " . $wpdb->prefix . "country WHERE %d", 1 ), OBJECT_K );
    do {
        $resultsfromcrm = $CrmOperationsobj->getCrmEntityDetails( 'new_country', array( 'type' => 'and', 'conditions' => array( array( 'attribute' => 'statecode', 'operator' => 'eq', 'value' => 'Active' ) ) ), 'list', null, $start, $limit );
        $countryinsertsql = "";
        $deleteCountryID = "";

        $deleteCountrySql = ' delete from ' . $wpdb->prefix . 'country where crm_id not in (';
        $i = 1;
        try {
            foreach ( $resultsfromcrm->Entities as $countryresult ) {
                $countryresult->new_countryid = strtolower( $countryresult->new_countryid );
                if ( isset( $country_data[$countryresult->new_countryid]->crm_id ) && $country_data[$countryresult->new_countryid]->crm_id == $countryresult->new_countryid ) {
                    if ( key_exists($countryresult->new_countryid, $country_data) && ($country_data[$countryresult->new_countryid]->country != $countryresult->new_name) ) {
                        $countryupdatesql = "UPDATE " . $wpdb->prefix . "country SET  `country` = '" . addslashes( $countryresult->new_name ) . "' where crm_id like '" . $countryresult->new_countryid . "'";
                        $country_update_result = $wpdb->query( $countryupdatesql );
                        if ( $country_update_result instanceof WP_Error ) {
                            $result_messages[$countryresult->new_name]['messages'][] = __( 'Unable to insert data in portal for country having portal name' ) . ":" . $countryresult->new_name;
                            $result_messages[$countryresult->new_name]['result'][] = "error";
                        } else {
                            $result_messages[$countryresult->new_name]['messages'][] = __( 'Data updated successfully for country having portal name' ) . ":" . $countryresult->new_name;
                            $result_messages[$countryresult->new_name]['result'][] = "success";
                        }
                    }
                } else {
                    $countryinsertsql = "insert into " . $wpdb->prefix . "country (`country`,`crm_id`) values ('" . addslashes( $countryresult->new_name ) . "'" . "," . "'" . $countryresult->new_countryid . "')";
                    $country_insert_result = $wpdb->query( $countryinsertsql );
                    if ( $country_insert_result instanceof WP_Error ) {
                        $result_messages[$countryresult->new_name]['messages'][] = __( 'Unable to insert data in portal for country having portal name' ) . ":" . $countryresult->new_name;
                        $result_messages[$countryresult->new_name]['result'][] = "error";
                    } else {
                        $result_messages[$countryresult->new_name]['messages'][] = __( 'Data inserted successfully for country having portal name' ) . ":" . $countryresult->new_name;
                        $result_messages[$countryresult->new_name]['result'][] = "success";
                    }
                }
                if ( $i != 1 ) {
                    $deleteCountryID .= ",'" . $countryresult->new_countryid . "'";
                } else {
                    $deleteCountryID .= "'" . $countryresult->new_countryid . "'";
                }
                $i ++;
            }
        } catch ( Exception $e ) {
            if ( $cron_output && ! empty( $result_messages ) ) {
                $result_messages[$countryresult->new_name]['result'][0] = "error";
                $result_messages[$countryresult->new_name]['messages'][] = "Error Code:" . $e->getCode() . ", Error Line:" . $e->getLine() . ", Error Message:" . $e->getMessage() . ", country having portal name :" . $countryresult->new_name;
            }
        }
        if ( $cron_output && ! empty( $result_messages ) ) {
            echo json_encode( $result_messages );
        } else {
            $log_messages['0']['result'][0] = "notice";
            $log_messages['0']['messages'][] = __( 'No Country found for update or insert' );
            if ( $cron_output && ! empty( $log_messages ) ) {
                echo json_encode( $log_messages );
            }
        }
        $deleteCountrySql .= $deleteCountryID . ")";
        if ( isset( $deleteCountryID ) && $deleteCountryID != "" ) {
            $wpdb->query( $deleteCountrySql );
        }
        $start ++;
    } while ( $resultsfromcrm->MoreRecords == 1 );
}

function fetch_application_via_crm_id() {

	global $wpdb;
	$crmOperationsObj = getCrmConnection();
	$start = 1;
	$length = 1000;
	$where = array( 'type' => 'and' );
	$result = $wpdb->get_results( $wpdb->prepare( "SELECT apd.crm_id FROM {$wpdb->prefix}application_data as apd"
			. " JOIN {$wpdb->prefix}certificate as cert on cert.id = apd.certificate_id "
			. " where ((cert.staff_last_notified_on IS NOT NULL AND cert.staff_last_notified_on != %s)"
			. " OR (cert.customer_last_notified_on IS NOT NULL AND cert.customer_last_notified_on != %s)) "
			. "AND cert.is_renewed=0 AND apd.crm_id IS NOT NULL", '0000-00-00 00:00:00', '0000-00-00 00:00:00' ) );

	for ( $j = 0; $j < count( $result ); $j ++ ) {
		$new_app_data[$result[$j]->crm_id] = $result[$j];
	}
	do {
		$app_data = $crmOperationsObj->getCrmEntityDetails( 'new_application', $where, 'list', null, $start, $length );
		save_data_for_application( $app_data->Entities, $new_app_data );
		$start ++;
	} while ( $app_data->MoreRecords == 1 );
}

function save_data_for_application( $app_data, $new_app_data ) {
	global $wpdb;
	global $cron_output;
	$result_messages = $app_array = array();
	$crmOperationsObj = getCrmConnection();
	$result_messages = array();
	//fetch applications
	$i = 0;
	foreach ( $app_data as $application ) {
		try {
			if ( ! empty( $new_app_data ) && isset( $new_app_data[$application->new_applicationid]->crm_id ) && isset( $application->new_applicationid ) && $new_app_data[$application->new_applicationid]->crm_id == $application->new_applicationid ) {
				if ( isset( $app_array ) && ! empty( $app_array ) ) {
					unset( $app_array );
					$app_array = array();
				}
				if ( isset( $application->new_population->Value ) ) {
					$app_array['new_application']['new_population'] = $application->new_population->Value;
				}
				if ( isset( $application->new_noofemployeesfa->Value ) ) {
					$app_array['new_application']['new_noofemployeesfa'] = $application->new_noofemployeesfa->Value;
				}
				if ( isset( $application->new_noofemployeesbda->Value ) ) {
					$app_array['new_application']['new_noofemployeesbda'] = $application->new_noofemployeesbda->Value;
				}
				if ( isset( $application->new_noofemployeesmba->Value ) ) {
					$app_array['new_application']['new_noofemployeesmba'] = $application->new_noofemployeesmba->Value;
				}
				if ( isset( $application->new_noofemployeesfpd->Value ) ) {
					$app_array['new_application']['new_noofemployeesfpd'] = $application->new_noofemployeesfpd->Value;
				}
				if ( isset( $application->new_noofemployeestpp->Value ) ) {
					$app_array['new_application']['new_noofemployeestpp'] = $application->new_noofemployeestpp->Value;
				}
				if ( isset( $application->new_customerid->Id ) ) {
					$customer = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'company WHERE crm_id= %s', $application->new_customerid->Id ) );
					$app_array['new_application']['_linked']['account']['new_customerid'] = $customer->id;
				}
				if ( isset( $application->new_certificate->new_labcountryid ) ) {
					$new_labcountryid = $application->new_certificate->new_labcountryid;
					$new_labcountryid = substr( $new_labcountryid, 0, strpos( $new_labcountryid, "new_country" ) );
					$labcountry = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'country WHERE crm_id= %s', $new_labcountryid ) );
					$app_array['new_application']['_linked']['new_country']['new_labcountryid'] = $labcountry->id;
				}
				if ( isset( $application->new_countryid->Id ) ) {
					$country = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'country WHERE crm_id= %s', $application->new_countryid->Id ) );
					$app_array['new_application']['_linked']['new_country']['new_countryid'] = $country->id;
				}
				if ( isset( $application->new_certificate->new_labstateid ) ) {
					$new_labstateid = $application->new_certificate->new_labstateid;
					$new_labstateid = substr( $new_labstateid, 0, strpos( $new_labstateid, "new_state" ) );
					$labstate = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'state WHERE crm_id= %s', $new_labstateid ) );
					$app_array['new_application']['_linked']['new_state']['new_labstateid'] = $labstate->id;
				}
				if ( isset( $application->new_stateid->Id ) ) {
					$state = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'state WHERE crm_id= %s', $application->new_stateid->Id ) );
					$app_array['new_application']['_linked']['new_state']['new_stateid'] = $state->id;
				}
				if ( isset( $application->new_certificate->new_inspectionagencycertid ) ) {
					$new_inspectionid = $application->new_certificate->new_inspectionagencycertid;
					$new_inspectionid = substr( $new_inspectionid, 0, strpos( $new_inspectionid, "new_certificate" ) );
					$new_inspectionid = str_replace( $new_inspectionid, '', $application->new_certificate->new_inspectionagencycertid );
					$new_inspectionid = str_replace( 'new_certificate', '', $new_inspectionid );
					$app_array['new_application']['_linked']['new_certificate']['new_inspectionagencycert'] = $new_inspectionid;
				}

				if ( isset( $application->new_technicalcontactid->Id ) ) {
					$new_technicalcontactid = $application->new_technicalcontactid->Id;
					$technical = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_technicalcontactid ) );
					if ( isset( $technical ) && ! empty( $technical ) ) {
						$app_array['new_application']['_linked']['contact']['new_technicalcontactid'] = $technical->id;
						$app_array['new_application']['applicanttechtitle'] = $technical->title;
						$app_array['new_application']['applicanttechadd'] = $technical->address;
						$app_array['new_application']['applicanttechnumber'] = $technical->phone;
						$app_array['new_application']['applicanttechfax'] = $technical->fax;
						$app_array['new_application']['applicanttechemail'] = $technical->user_email;
					}
				} else if ( isset( $application->new_certificate->new_technicalcontactid ) ) {
					$new_technicalcontactid = $application->new_certificate->new_technicalcontactid;
					$new_technicalcontactid = substr( $new_technicalcontactid, 0, strpos( $new_technicalcontactid, "contact" ) );
					$technical = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_technicalcontactid ) );
					if ( isset( $technical ) && ! empty( $technical ) ) {
						$app_array['new_application']['_linked']['contact']['new_technicalcontactid'] = $technical->id;
						$app_array['new_application']['applicanttechtitle'] = $technical->title;
						$app_array['new_application']['applicanttechadd'] = $technical->address;
						$app_array['new_application']['applicanttechnumber'] = $technical->phone;
						$app_array['new_application']['applicanttechfax'] = $technical->fax;
						$app_array['new_application']['applicanttechemail'] = $technical->user_email;
					}
				}

				if ( isset( $application->new_legalcontactid->Id ) ) {
					$new_legalcontactid = $application->new_legalcontactid->Id;
					$legal = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_legalcontactid ) );
					if ( isset( $legal ) && ! empty( $legal ) ) {
						$app_array['new_application']['_linked']['contact']['new_legalcontactid'] = $legal->id;
						$app_array['new_application']['applicantlegaltitle'] = $legal->title;
						$app_array['new_application']['applicantlegaladd'] = $legal->address;
						$app_array['new_application']['applicantlegalnumber'] = $legal->phone;
						$app_array['new_application']['applicantlegalfax'] = $legal->fax;
						$app_array['new_application']['applicantlegalemail'] = $legal->user_email;
					}
				} else if ( isset( $application->new_certificate->new_legalcontactid ) ) {
					$new_legalcontactid = $application->new_certificate->new_legalcontactid;
					$new_legalcontactid = substr( $new_legalcontactid, 0, strpos( $new_legalcontactid, "contact" ) );
					$legal = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_legalcontactid ) );
					if ( isset( $legal ) && ! empty( $legal ) ) {
						$app_array['new_application']['_linked']['contact']['new_legalcontactid'] = $legal->id;
						$app_array['new_application']['applicantlegaltitle'] = $legal->title;
						$app_array['new_application']['applicantlegaladd'] = $legal->address;
						$app_array['new_application']['applicantlegalnumber'] = $legal->phone;
						$app_array['new_application']['applicantlegalfax'] = $legal->fax;
						$app_array['new_application']['applicantlegalemail'] = $legal->user_email;
					}
				}

				if ( isset( $application->new_chiefadminofficerid->Id ) ) {
					$new_chiefcontactid = $application->new_chiefadminofficerid->Id;
					$chief = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_chiefcontactid ) );
					if ( isset( $chief ) && ! empty( $chief ) ) {
						$app_array['new_application']['_linked']['contact']['new_chiefadminofficerid'] = $chief->id;
						$app_array['new_application']['applicantchieftitle'] = $chief->title;
						$app_array['new_application']['applicantchiefadd'] = $chief->address;
						$app_array['new_application']['applicantchiefnumber'] = $chief->phone;
						$app_array['new_application']['applicantchieffax'] = $chief->fax;
						$app_array['new_application']['applicantchiefemail'] = $chief->user_email;
					}
				}


				if ( isset( $application->new_billingcontact->Id ) ) {
					$new_billingcontactid = $application->new_billingcontact->Id;
					$billing = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_billingcontactid ) );
					if ( isset( $billing ) && ! empty( $billing ) ) {
						$app_array['new_application']['_linked']['contact']['new_billingcontact'] = $billing->id;
						$app_array['new_application']['applicantbillingtitle'] = $billing->title;
						$app_array['new_application']['applicantbillingadd'] = $billing->address;
						$app_array['new_application']['applicantbillingnumber'] = $billing->phone;
						$app_array['new_application']['applicantbillingfax'] = $billing->fax;
						$app_array['new_application']['applicantbillingemail'] = $billing->user_email;
					}
				} else if ( isset( $application->new_certificate->new_billingcontactid ) ) {
					$new_billingcontactid = $application->new_certificate->new_billingcontactid;
					$new_billingcontactid = substr( $new_billingcontactid, 0, strpos( $new_billingcontactid, "contact" ) );
					$billing = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_billingcontactid ) );
					if ( isset( $billing ) && ! empty( $billing ) ) {
						$app_array['new_application']['_linked']['contact']['new_billingcontact'] = $billing->id;
						$app_array['new_application']['applicantbillingtitle'] = $billing->title;
						$app_array['new_application']['applicantbillingadd'] = $billing->address;
						$app_array['new_application']['applicantbillingnumber'] = $billing->phone;
						$app_array['new_application']['applicantbillingfax'] = $billing->fax;
						$app_array['new_application']['applicantbillingemail'] = $billing->user_email;
					}
				}

				if ( isset( $application->new_certificate->new_sameasmailing ) ) {
					$app_array['new_application']['new_sameasmailing'] = 1;
				}
				if ( isset( $application->new_jurisdictionname ) ) {
					$app_array['new_application']['new_jurisdictionname'] = $application->new_jurisdictionname;
				}
				if ( isset( $application->new_nfipnumber->Value ) ) {
					$app_array['new_application']['new_nfipnumber'] = $application->new_nfipnumber->Value;
				}
				if ( isset( $application->new_jurisdictionest_new ) ) {
					$app_array['new_application']['new_jurisdictionest_new'] = $application->new_jurisdictionest_new;
				}
				if ( isset( $application->new_departmentest_new ) ) {
					$app_array['new_application']['new_departmentest_new'] = $application->new_departmentest_new;
				}
				if ( isset( $application->new_jurisdictionsize->Value ) ) {
					$app_array['new_application']['new_jurisdictionsize'] = $application->new_jurisdictionsize->Value;
				}
				if ( isset( $application->new_jurisdictionsservedbydept ) ) {
					$app_array['new_application']['new_jurisdictionsservedbydept'] = $application->new_jurisdictionsservedbydept;
				}
				if ( isset( $application->new_certificate->new_labaddressstreet1 ) ) {
					$app_array['new_application']['new_labaddressstreet1'] = $application->new_certificate->new_labaddressstreet1;
				}
				if ( isset( $application->new_certificate->new_labcity ) ) {
					$app_array['new_application']['new_labcity'] = $application->new_certificate->new_labcity;
				}
				if ( isset( $application->new_certificate->new_labzippostalcode ) ) {
					$app_array['new_application']['new_labzippostalcode'] = $application->new_certificate->new_labzippostalcode;
				}
				if ( isset( $application->new_certificate->new_addressstreet1 ) ) {
					$app_array['new_application']['new_addressstreet1'] = $application->new_certificate->new_addressstreet1;
				}
				if ( isset( $application->new_certificate->new_city ) ) {
					$app_array['new_application']['new_city'] = $application->new_certificate->new_city;
				}
				if ( isset( $application->new_certificate->new_zippostalcode ) ) {
					$app_array['new_application']['new_zippostalcode'] = $application->new_certificate->new_zippostalcode;
				}
				if ( isset( $application->new_county ) && $application->new_county != '' ) {
					$app_array['new_application']['new_county'] = $application->new_county;
				}


				if ( $new_app_data[$application->new_applicationid]->crm_id != '' ) {
					$task_crm_id = $wpdb->get_var( $wpdb->prepare( 'SELECT task_crm_id FROM ' . $wpdb->prefix . 'application_data WHERE crm_id= %s', $new_app_data[$application->new_applicationid]->crm_id ) );
					$app_array['new_application']['externalurl'] = get_application_external_url_by_task_crm_id( $task_crm_id );
				}
				if ( isset( $application->account->accountid ) && $application->account->accountid != '' ) {
					$company = $wpdb->get_row( $wpdb->prepare( 'SELECT id,email,fax,phone,website_url FROM ' . $wpdb->prefix . 'company WHERE crm_id= %s', $application->account->accountid ) );
					$app_array['new_application']['telenumber'] = $company->phone;
					$app_array['new_application']['faxno'] = $company->fax;
					$app_array['new_application']['emailadd'] = $company->email;
					$app_array['new_application']['webadd'] = $company->website_url;
				}

				$app_db_data = $wpdb->get_row( $wpdb->prepare( "select application_data from {$wpdb->prefix}application_data where id= %d", $new_app_data[$application->new_applicationid]->application_id ) );
				if ( ! empty( $app_db_data->application_data ) ) {
					$new_app_array = json_decode( $app_db_data->application_data, true );
					if ( is_array( $new_app_array ) )
						$app_array = array_replace_recursive( $new_app_array, $app_array );
				}
				$app_update_result = $wpdb->query( $wpdb->prepare( "update {$wpdb->prefix}application_data set application_data= %s where id= %d", json_encode( $app_array ), $new_app_data[$application->new_applicationid]->application_id ) );
				if ( $app_update_result instanceof WP_Error ) {
					$result_messages[$new_app_data[$application->new_applicationid]->application_id]['messages'][] = __( 'Unable to insert data in portal for application having portal id' ) . ":" . $new_app_data[$application->new_applicationid]->application_id;
					$result_messages[$new_app_data[$application->new_applicationid]->application_id]['result'][] = "error";
				} else {
					$result_messages[$new_app_data[$application->new_applicationid]->application_id]['messages'][] = __( 'Data inserted successfully for application having portal id' ) . ":" . $new_app_data[$application->new_applicationid]->application_id;
					$result_messages[$new_app_data[$application->new_applicationid]->application_id]['result'][] = "success";
				}
			}
		} catch ( Exception $e ) {

			$result_messages[$new_app_data[$application->new_applicationid]->application_id]['result'][0] = "error";
			$result_messages[$new_app_data[$application->new_applicationid]->application_id]['messages'][] = "Error Code:" . $e->getCode() . ", Error Line:" . $e->getLine() . ", Error Message:" . $e->getMessage() . ", application having portal id :" . $new_app_data[$application->new_applicationid]->application_id;
		}
	}
	if ( $cron_output && ! empty( $result_messages ) ) {
		echo json_encode( $result_messages );
	}
}

/* 0846 function to fetch application using crm id */

function fetch_app_via_crm_id() {
	global $wpdb;
	isset( $_POST['length'] ) ? $lenght = $_POST['length'] : $lenght = 1;
	isset( $_POST['start'] ) ? $start = $_POST['start'] : $start = 0; //ceil($a / 50) + 1
	$start = ceil( $start / 10 ) + 1;
	//$where = array('type' => 'and');
//    if (isset($_REQUEST['crm_id']) and ! empty($_REQUEST['crm_id'])) {
//        $crm_id = $_REQUEST['crm_id'];
//      $where['conditions'][] = array('attribute' => 'new_applicationid', 'operator' => 'eq', 'value' => "$crm_id");
//    }

	$result = $wpdb->get_results( $wpdb->prepare( "SELECT apd.crm_id, apd.id as application_id FROM {$wpdb->prefix}application_data as apd JOIN {$wpdb->prefix}certificate as cert on cert.certificate_id = apd.id where ((cert.staff_last_notified_on IS NOT NULL AND cert.staff_last_notified_on != %s) OR (cert.customer_last_notified_on IS NOT NULL AND cert.customer_last_notified_on != %s)) AND cert.is_renewed=0 AND apd.crm_id IS NOT NULL AND apd.application_data = ''", '0000-00-00 00:00:00', '0000-00-00 00:00:00' ) );
	if ( $wpdb->num_rows > 0 ) {
		foreach ( $result as $value ) {
			$where = array( 'type' => 'and' );
			$where['conditions'][] = array( 'attribute' => 'new_applicationid', 'operator' => 'eq', 'value' => "$value->crm_id" );

			$CrmOperationsobj = new CrmOperations();
			$resultsfromcrm = $CrmOperationsobj->getCrmEntityDetails( 'new_application', $where, 'list', '', $start, $lenght );
			foreach ( $resultsfromcrm->Entities as $val ) {
				if ( isset( $app_array ) && ! empty( $app_array ) ) {
					unset( $app_array );
					$app_array = array();
				}
				if ( isset( $val->new_population->Value ) ) {
					$app_array['new_application']['new_population'] = $val->new_population->Value;
				}
				if ( isset( $val->new_noofemployeesfa->Value ) ) {
					$app_array['new_application']['new_noofemployeesfa'] = $val->new_noofemployeesfa->Value;
				}
				if ( isset( $val->new_noofemployeesbda->Value ) ) {
					$app_array['new_application']['new_noofemployeesbda'] = $val->new_noofemployeesbda->Value;
				}
				if ( isset( $val->new_customerid->Id ) ) {
					$customer = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'company WHERE crm_id = %s ', $val->new_customerid->Id ) );
					$app_array['new_application']['_linked']['account']['new_customerid'] = $customer->id;
				}
				if ( isset( $val->new_certificate->new_labcountryid ) ) {
					$new_labcountryid = $val->new_certificate->new_labcountryid;
					$new_labcountryid = substr( $new_labcountryid, 0, strpos( $new_labcountryid, "new_country" ) );
					$labcountry = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'country WHERE crm_id= %s', $new_labcountryid ) );
					$app_array['new_application']['_linked']['new_country']['new_labcountryid'] = $labcountry->id;
				}
				if ( isset( $val->new_countryid->Id ) ) {
					$country = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'country WHERE crm_id= %s', $val->new_countryid->Id ) );
					$app_array['new_application']['_linked']['new_country']['new_countryid'] = $country->id;
				}
				if ( isset( $val->new_certificate->new_labstateid ) ) {
					$new_labstateid = $val->new_certificate->new_labstateid;
					$new_labstateid = substr( $new_labstateid, 0, strpos( $new_labstateid, "new_state" ) );
					$labstate = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'state WHERE crm_id= %s', $new_labstateid ) );
					$app_array['new_application']['_linked']['new_state']['new_labstateid'] = $labstate->id;
				}
				if ( isset( $val->new_stateid->Id ) ) {
					$state = $wpdb->get_row( $wpdb->prepare( 'SELECT id FROM ' . $wpdb->prefix . 'state WHERE crm_id= %s', $val->new_stateid->Id ) );
					$app_array['new_application']['_linked']['new_state']['new_stateid'] = $state->id;
				}
				if ( isset( $val->new_certificate->new_inspectionagencycertid ) ) {
					$new_inspectionid = $val->new_certificate->new_inspectionagencycertid;
					$new_inspectionid = substr( $new_inspectionid, 0, strpos( $new_inspectionid, "new_certificate" ) );
					$new_inspectionid = str_replace( $new_inspectionid, '', $val->new_certificate->new_inspectionagencycertid );
					$new_inspectionid = str_replace( 'new_certificate', '', $new_inspectionid );
					$app_array['new_application']['_linked']['new_certificate']['new_inspectionagencycert'] = $new_inspectionid;
				}

				if ( isset( $val->new_technicalcontactid->Id ) ) {
					$new_technicalcontactid = $val->new_technicalcontactid->Id;
					//$new_technicalcontactid = substr($new_technicalcontactid, 0, strpos($new_technicalcontactid, "contact"));
					$technical = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_technicalcontactid ) );
					if ( isset( $technical ) && ! empty( $technical ) ) {
						$app_array['new_application']['_linked']['contact']['new_technicalcontactid'] = $technical->id;
						$app_array['new_application']['applicanttechtitle'] = $technical->title;
						$app_array['new_application']['applicanttechadd'] = $technical->address;
						$app_array['new_application']['applicanttechnumber'] = $technical->phone;
						$app_array['new_application']['applicanttechfax'] = $technical->fax;
						$app_array['new_application']['applicanttechemail'] = $technical->user_email;
					}
				} else if ( isset( $val->new_certificate->new_technicalcontactid ) ) {
					$new_technicalcontactid = $val->new_certificate->new_technicalcontactid;
					$new_technicalcontactid = substr( $new_technicalcontactid, 0, strpos( $new_technicalcontactid, "contact" ) );
					$technical = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_technicalcontactid ) );
					if ( isset( $technical ) && ! empty( $technical ) ) {
						$app_array['new_application']['_linked']['contact']['new_technicalcontactid'] = $technical->id;
						$app_array['new_application']['applicanttechtitle'] = $technical->title;
						$app_array['new_application']['applicanttechadd'] = $technical->address;
						$app_array['new_application']['applicanttechnumber'] = $technical->phone;
						$app_array['new_application']['applicanttechfax'] = $technical->fax;
						$app_array['new_application']['applicanttechemail'] = $technical->user_email;
					}
				}

				if ( isset( $val->new_legalcontactid->Id ) ) {
					$new_legalcontactid = $val->new_legalcontactid->Id;
					//$new_legalcontactid = substr($new_legalcontactid, 0, strpos($new_legalcontactid, "contact"));
					$legal = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_legalcontactid ) );
					if ( isset( $legal ) && ! empty( $legal ) ) {
						$app_array['new_application']['_linked']['contact']['new_legalcontactid'] = $legal->id;
						$app_array['new_application']['applicantlegaltitle'] = $legal->title;
						$app_array['new_application']['applicantlegaladd'] = $legal->address;
						$app_array['new_application']['applicantlegalnumber'] = $legal->phone;
						$app_array['new_application']['applicantlegalfax'] = $legal->fax;
						$app_array['new_application']['applicantlegalemail'] = $legal->user_email;
					}
				} else if ( isset( $val->new_certificate->new_legalcontactid ) ) {
					$new_legalcontactid = $val->new_certificate->new_legalcontactid;
					$new_legalcontactid = substr( $new_legalcontactid, 0, strpos( $new_legalcontactid, "contact" ) );
					$legal = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_legalcontactid ) );
					if ( isset( $legal ) && ! empty( $legal ) ) {
						$app_array['new_application']['_linked']['contact']['new_legalcontactid'] = $legal->id;
						$app_array['new_application']['applicantlegaltitle'] = $legal->title;
						$app_array['new_application']['applicantlegaladd'] = $legal->address;
						$app_array['new_application']['applicantlegalnumber'] = $legal->phone;
						$app_array['new_application']['applicantlegalfax'] = $legal->fax;
						$app_array['new_application']['applicantlegalemail'] = $legal->user_email;
					}
				}

				if ( isset( $val->new_chiefadminofficerid->Id ) ) {
					$new_chiefcontactid = $val->new_chiefadminofficerid->Id;
					//$new_chiefcontactid = substr($new_chiefcontactid, 0, strpos($new_chiefcontactid, "contact"));
					$chief = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_chiefcontactid ) );
					if ( isset( $chief ) && ! empty( $chief ) ) {
						$app_array['new_application']['_linked']['contact']['new_chiefadminofficerid'] = $chief->id;
						$app_array['new_application']['applicantchieftitle'] = $chief->title;
						$app_array['new_application']['applicantchiefadd'] = $chief->address;
						$app_array['new_application']['applicantchiefnumber'] = $chief->phone;
						$app_array['new_application']['applicantchieffax'] = $chief->fax;
						$app_array['new_application']['applicantchiefemail'] = $chief->user_email;
					}
				}


				if ( isset( $val->new_billingcontact->Id ) ) {
					$new_billingcontactid = $val->new_billingcontact->Id;
					//$new_billingcontactid = substr($new_billingcontactid, 0, strpos($new_billingcontactid, "contact"));
					$billing = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_billingcontactid ) );
					if ( isset( $billing ) && ! empty( $billing ) ) {
						$app_array['new_application']['_linked']['contact']['new_billingcontact'] = $billing->id;
						$app_array['new_application']['applicantbillingtitle'] = $billing->title;
						$app_array['new_application']['applicantbillingadd'] = $billing->address;
						$app_array['new_application']['applicantbillingnumber'] = $billing->phone;
						$app_array['new_application']['applicantbillingfax'] = $billing->fax;
						$app_array['new_application']['applicantbillingemail'] = $billing->user_email;
					}
				} else if ( isset( $val->new_certificate->new_billingcontactid ) ) {
					$new_billingcontactid = $val->new_certificate->new_billingcontactid;
					$new_billingcontactid = substr( $new_billingcontactid, 0, strpos( $new_billingcontactid, "contact" ) );
					$billing = $wpdb->get_row( $wpdb->prepare( 'SELECT id,phone,fax,title,address,user_email FROM ' . $wpdb->prefix . 'users WHERE crm_id= %s', $new_billingcontactid ) );
					if ( isset( $billing ) && ! empty( $billing ) ) {
						$app_array['new_application']['_linked']['contact']['new_billingcontact'] = $billing->id;
						$app_array['new_application']['applicantbillingtitle'] = $billing->title;
						$app_array['new_application']['applicantbillingadd'] = $billing->address;
						$app_array['new_application']['applicantbillingnumber'] = $billing->phone;
						$app_array['new_application']['applicantbillingfax'] = $billing->fax;
						$app_array['new_application']['applicantbillingemail'] = $billing->user_email;
					}
				}

				if ( isset( $val->new_certificate->new_sameasmailing ) ) {
					$app_array['new_application']['new_sameasmailing'] = 1;
				}
				if ( isset( $val->new_jurisdictionname ) ) {
					$app_array['new_application']['new_jurisdictionname'] = $val->new_jurisdictionname;
				}
				if ( isset( $val->new_nfipnumber->Value ) ) {
					$app_array['new_application']['new_nfipnumber'] = $val->new_nfipnumber->Value;
				}
				if ( isset( $val->new_jurisdictionest_new ) ) {
					$app_array['new_application']['new_jurisdictionest_new'] = $val->new_jurisdictionest_new;
				}
				if ( isset( $val->new_departmentest_new ) ) {
					$app_array['new_application']['new_departmentest_new'] = $val->new_departmentest_new;
				}
				if ( isset( $val->new_jurisdictionsize->Value ) ) {
					$app_array['new_application']['new_jurisdictionsize'] = $val->new_jurisdictionsize->Value;
				}
				if ( isset( $val->new_jurisdictionsservedbydept ) ) {
					$app_array['new_application']['new_jurisdictionsservedbydept'] = $val->new_jurisdictionsservedbydept;
				}
				if ( isset( $val->new_certificate->new_labaddressstreet1 ) ) {
					$app_array['new_application']['new_labaddressstreet1'] = $val->new_certificate->new_labaddressstreet1;
				}
				if ( isset( $val->new_certificate->new_labcity ) ) {
					$app_array['new_application']['new_labcity'] = $val->new_certificate->new_labcity;
				}
				if ( isset( $val->new_certificate->new_labzippostalcode ) ) {
					$app_array['new_application']['new_labzippostalcode'] = $val->new_certificate->new_labzippostalcode;
				}
				//$app_array['new_application']['new_certificate.new_sameasmailing'] = $val->new_certificate.new_sameasmailing;
				if ( isset( $val->new_certificate->new_addressstreet1 ) ) {
					$app_array['new_application']['new_addressstreet1'] = $val->new_certificate->new_addressstreet1;
				}
				if ( isset( $val->new_certificate->new_city ) ) {
					$app_array['new_application']['new_city'] = $val->new_certificate->new_city;
				}
				if ( isset( $val->new_certificate->new_zippostalcode ) ) {
					$app_array['new_application']['new_zippostalcode'] = $val->new_certificate->new_zippostalcode;
				}
				if ( isset( $val->new_county ) ) {
					$app_array['new_application']['new_county'] = $val->new_county;
				}


				if ( $value->crm_id != '' ) {
					$task_crm_id = $wpdb->get_var( $wpdb->prepare( 'SELECT task_crm_id FROM ' . $wpdb->prefix . 'application_data WHERE crm_id= %s', $value->crm_id ) );
					$app_array['new_application']['externalurl'] = get_application_external_url_by_task_crm_id( $task_crm_id );
				}
				if ( isset( $val->account->accountid ) ) {
					$company = $wpdb->get_row( $wpdb->prepare( 'SELECT id,email,fax,phone,website_url FROM ' . $wpdb->prefix . 'company WHERE crm_id= %s', $val->account->accountid ) );
					$app_array['new_application']['telenumber'] = $company->phone;
					$app_array['new_application']['faxno'] = $company->fax;
					$app_array['new_application']['emailadd'] = $company->email;
					$app_array['new_application']['webadd'] = $company->website_url;
				}
			}
			$wpdb->query( $wpdb->prepare( "update {$wpdb->prefix}application_data set application_data= %s where id= %d", json_encode( $app_array ), $value->application_id ) );
		}
	}
}

/* Invoice pull from crm and stored in wp_invoices table */

function invoice_pull_from_crm() {
	global $wpdb;
	global $cron_output;
	$CrmOperationsobj = getCrmConnection();
	$db_operations = DbOperations::getInstance();
	$where = '';
	$last_cron_date = get_option( 'last_cron_run_for_invoice_pull' );
	$last_cron = date( "Y-m-d", strtotime( $last_cron_date ) );
	if ( isset( $last_cron_date ) && ( ! empty( $last_cron_date )) ) {
		$where = array( 'type' => 'and' );
		$where['conditions'][] = array( 'attribute' => 'createdon', 'operator' => 'on-or-after', 'value' => $last_cron_date );
	}
	//$CrmOperationsobj->crmConnector->setMaximumRecords(1000);
	$start = '1';
	$limit = '1000';
	$haverecords = true;
	$totalRecordsFetched = $totalRecordsCreated = $totalRecordsUpdated = 0;
	$bnfw = BNFW::factory();
	do {
		$resultsfromcrm = $CrmOperationsobj->getCrmEntityDetails( 'invoice', $where, 'list', null, $start, $limit );
		$totalRecordsFetched = $resultsfromcrm->TotalRecordCount;
		foreach ( $resultsfromcrm->Entities as $result_key => $result ) {
			$certificateid = (isset( $result->new_certificateid->Value->Id )) ? $result->new_certificateid->Value->Id : "";
			$crm_id = (isset( $result->invoiceid )) ? $result->invoiceid : '';
			$created_on = (isset( $result->createdon->Value )) ? $result->createdon->Value : "";
			$company_crm_id = (isset( $result->customerid->Value->Id )) ? $result->customerid->Value->Id : "";
			$invoice_name = (isset( $result->name )) ? $result->name : "";
			$company_id = $wpdb->get_var( $wpdb->prepare( 'select id from ' . $wpdb->prefix . 'company where crm_id =  %s', trim( $company_crm_id ) ) );
			$invoice_status = (isset( $result->statecode->FormattedValue )) ? $result->statecode->FormattedValue : '';
			$sql = $wpdb->prepare( 'select * from ' . $wpdb->prefix . 'invoices where crm_id = %s', $crm_id );
			$invoice_result = $wpdb->get_results( $sql );
			//In case of invoice found at portal
			if ( isset( $invoice_result ) && ( ! empty( $invoice_result )) ) {
				$existing_invoice_status = $invoice_result[0]->status;
				//In case of existing invoice is found active on portal but from CRM it is found paid
				if ( ( ! empty( $invoice_status )) && (strtolower( $existing_invoice_status ) != 'paid') && (strtolower( $invoice_status ) == 'paid') ) {
					if ( $bnfw->notifier->notification_exists( "invoice-paid-found-from-crm-to-portal-for-customer" ) && SEND_INVOICE_PULL_FROM_CRM_NOTIFICATION ) {
						$db_operations = DbOperations::getInstance();
						$certificate_data = $db_operations->get_certificate_data( null, $certificateid );
						//$invoice_data = $db_operations->get_application_data_by_invoice_crm_id($crm_id);
						//$company_data = $db_operations->get_company_data_by_id($certificate_data->company_id);
						if ( isset( $certificate_data->user_id ) and ! is_null( $certificate_data->user_id ) and $certificate_data->user_id != 0 ) {
							$user_result = get_userdata( $certificate_data->user_id );
							$notifications = $bnfw->notifier->get_notifications( "invoice-paid-found-from-crm-to-portal-for-customer" );
							if ( ( ! empty( $user_result )) && ( ! empty( $user_result->data )) && ( ! empty( $notifications )) ) {
								$emailaddress1 = $user_result->data->user_email;
								$notification = $notifications[0];
								$setting = $bnfw->notifier->read_settings( $notification->ID );
								$subjectmail = $setting['subject'];
								$subjectmail = str_replace( '[certificate_name]', stripslashes( $certificate_data->certificate_name ), $subjectmail );
								$messagemail = $setting['message'];
								$messagemail = str_replace( '[username]', stripslashes( $user_result->data->first_name . ' ' . $user_result->data->last_name ), $messagemail );
								$messagemail = str_replace( '[payment-status]', $invoice_status, $messagemail );
								$invoice_amount = format_currency( $result->totalamount->Value, 2, true );
								$messagemail = str_replace( '[payment-amount]', $invoice_amount, $messagemail );
								$due_invoice_amount = '';
								if ( isset( $result->new_balancedue->Value ) ) {
									$due_invoice_amount = 'Balance Due : ' . format_currency( $result->new_balancedue->Value, 2, true );
								}
								$messagemail = str_replace( '[due-amount]', $due_invoice_amount, $messagemail );
								$messagemail = trim( $messagemail );
								$mail_sent = wp_mail( $emailaddress1, stripslashes( $subjectmail ), wpautop( $messagemail ) );
							}
						}
					}
				}
				$wpdb->update( $wpdb->prefix . 'invoices', array( 'crm_id' => $crm_id, 'certificate_id' => $certificateid, 'company_id' => $company_id, 'company_crm_id' => $company_crm_id, 'invoice_name' => $invoice_name, 'created_on' => $created_on, 'status' => $invoice_status ), array( 'crm_id' => $crm_id ) );
				$totalRecordsUpdated ++;
			} else {
				$wpdb->insert( $wpdb->prefix . 'invoices', array( 'crm_id' => $crm_id, 'certificate_id' => $certificateid, 'company_id' => $company_id, 'company_crm_id' => $company_crm_id, 'invoice_name' => $invoice_name, 'invoice_docs' => '', 'created_on' => $created_on, 'status' => $invoice_status ) );                                
				$totalRecordsCreated ++;
				$certificate_data = $db_operations->get_certificate_data( null, $certificateid );
				//In case of inserted new invoice having status paid
				if ( ( ! empty( $invoice_status )) && (strtolower( $invoice_status ) == 'paid') ) {
					if ( $bnfw->notifier->notification_exists( "invoice-paid-found-from-crm-to-portal-for-customer" ) && SEND_INVOICE_PULL_FROM_CRM_NOTIFICATION ) {
						$db_operations = DbOperations::getInstance();
						//$certificate_data = $db_operations->get_application_data(null, $certificateid);
						//$invoice_data = $db_operations->get_application_data_by_invoice_crm_id($crm_id);
						//$company_data = $db_operations->get_company_data_by_id($certificate_data->company_id);
						if ( isset( $certificate_data->user_id ) and $certificate_data->user_id != 0 ) {
							$user_result = get_userdata( $certificate_data->user_id );
							$notifications = $bnfw->notifier->get_notifications( "invoice-paid-found-from-crm-to-portal-for-customer" );
							if ( ( ! empty( $user_result )) && ( ! empty( $user_result->data )) && ( ! empty( $notifications )) ) {
								$emailaddress1 = $user_result->data->user_email;
								$notification = $notifications[0];
								$setting = $bnfw->notifier->read_settings( $notification->ID );
								$subjectmail = $setting['subject'];
								$subjectmail = str_replace( '[certificate_name]', $certificate_data->certificate_name, $subjectmail );
								$messagemail = $setting['message'];
								$messagemail = str_replace( '[username]', stripslashes( $user_result->data->first_name . ' ' . $user_result->data->last_name ), $messagemail );
								$messagemail = str_replace( '[payment-status]', $invoice_status, $messagemail );
								$invoice_amount = format_currency( $result->totalamount->Value, 2, true );
								$messagemail = str_replace( '[payment-amount]', $invoice_amount, $messagemail );
								$due_invoice_amount = '';
								if ( isset( $result->new_balancedue->Value ) ) {
									$due_invoice_amount = 'Balance Due : ' . format_currency( $result->new_balancedue->Value, 2, true );
								}
								$messagemail = str_replace( '[due-amount]', $due_invoice_amount, $messagemail );
								$messagemail = trim( $messagemail );
								$mail_sent = wp_mail( $emailaddress1, stripslashes( $subjectmail ), wpautop( $messagemail ) );
							}
						}
					}
				} else {
					//Send invoice pulled notification to staff from CRM to portal
					if ( $bnfw->notifier->notification_exists( "invoice-pull-from-crm-to-portal-for-staff" ) && (((isset( $certificate_data )) && ( ! empty( $certificate_data ))) && ((int) $certificate_data->program_id) > 0) && SEND_INVOICE_PULL_FROM_CRM_NOTIFICATION ) {
						$staff_emails = get_option( 'invoice_pull_notification' );
						$valid_staff_emails = '';
						if ( isset( $staff_emails ) && ! empty( $staff_emails ) ) {
							$valid_staff_emails = getValidEmailForQuatationEmails( $staff_emails, true );
						}
						$valid_staff_emails = "'" . str_replace( ',', "','", $valid_staff_emails ) . "'";
						if ( ! empty( $valid_staff_emails ) ) {
							$sql = $wpdb->prepare( "select " . $wpdb->prefix . "users.* from " . $wpdb->prefix . "users where " . $wpdb->prefix . "users.user_type=%s and " . $wpdb->prefix . "users.user_email in ($valid_staff_emails) ", 'staff' );
							$staff_user_ids = $wpdb->get_results( $sql );
							foreach ( $staff_user_ids as $staff_user ) {
								if ( $bnfw->notifier->notification_exists( "invoice-pull-from-crm-to-portal-for-staff" ) ) {
									$notifications = $bnfw->notifier->get_notifications( "invoice-pull-from-crm-to-portal-for-staff" );
									if ( ( ! empty( $notifications )) && (isset( $staff_user->user_email )) ) {
										$firstname_users = $staff_user->display_name;
										$emailaddress1 = $staff_user->user_email;
										$notification = $notifications[0];
										$setting = $bnfw->notifier->read_settings( $notification->ID );
										$subjectmail = $setting['subject'];
										$messagemail = $setting['message'];
										$messagemail = str_replace( '[company-name]', $result->customerid->Name, $messagemail );
										$messagemail = str_replace( '[firstname]', stripslashes( $firstname_users ), $messagemail );
										$messagemail = str_replace( '[certificate-name]', $certificate_data->certificate_name, $messagemail );
										$messagemail = str_replace( '[invoice-name]', $invoice_name, $messagemail );
										$invoice_amount = format_currency( $result->totalamount->Value, 2, true );
										$messagemail = str_replace( '[invoice-amount]', $invoice_amount, $messagemail );
										$messagemail = trim( $messagemail );
										$mail_sent = wp_mail( $emailaddress1, stripslashes( $subjectmail ), wpautop( $messagemail ) );
									}
								}
							}
						}
					}
				}
			}
		}
		$start ++;
	} while ( $resultsfromcrm->MoreRecords == 1 );

	if ( ! empty( $last_cron_date ) ) {
		update_option( 'last_cron_run_for_invoice_pull', strtotime( 'now' ) );
	} else {
		add_option( 'last_cron_run_for_invoice_pull', strtotime( 'now' ) );
	}
	if ( $cron_output ) {
		echo "Fetched Records " . $totalRecordsFetched . "<br />";
		echo "Inserted Records " . $totalRecordsCreated . "<br />";
		echo "Updated Records " . $totalRecordsUpdated . "<br />";
	}
	die;
}

/**
 * Pull and import staff(systemusers) users from CRM to portal and store in wp_users table
 */
function pull_staff_from_crm() {
	global $wpdb;
	global $cron_output;
	$start = '1';
	$limit = '1000';
	$haverecords = true;
	$totalRecordsFetched = $totalRecordsCreated = $totalRecordsNotCreated = 0;
	$db_operations = DbOperations::getInstance();
	$crm_operations_obj = getCrmConnection();
	//$crm_operations_obj->crmConnector->setMaximumRecords(1000);
	do {
		try {
			$resultsfromcrm = $crm_operations_obj->getCrmEntityDetails( 'systemuser', null, 'list', null, $start, $limit );
			$totalRecordsFetched = $resultsfromcrm->TotalRecordCount;
			$start ++;
			if ( count( $resultsfromcrm ) > 0 ) {
				foreach ( $resultsfromcrm->Entities as $result_key => $result ) {
					if ( (isset( $result->internalemailaddress ) && ! empty( $result->internalemailaddress )) && (isset( $result->domainname ) && ! empty( $result->domainname )) ) {
						$user_login = (isset( $result->domainname ) && ( ! empty( $result->domainname ))) ? wp_slash( trim( stristr( $result->domainname, '\\' ), '\\' ) ) : '';
						$user_email = (isset( $result->internalemailaddress ) && ( ! empty( $result->internalemailaddress ))) ? wp_slash( trim( $result->internalemailaddress ) ) : '';
						$is_staff_exists = false;
						$sql = $wpdb->prepare( 'select id from ' . $wpdb->prefix . 'users where user_email = %s and user_type = "staff"', $user_email );
						$user_exist_result = $wpdb->get_row( $sql );
						if ( $wpdb->num_rows > 0 ) {
							$is_staff_exists = true;
						}
						//In case of staff user does not exists in the portal then import that user into portal
						if ( ! $is_staff_exists ) {
							$staff_user['user_login'] = $user_login;
							$staff_user['user_email'] = $user_email;
							remove_action( 'user_register', 'crm_user_register', 20 ); //As importing staff user so no need to generate lead on CRM so don't generating lead on CRM
							remove_filter( 'user_contactmethods', 'remove_password_from_profile', 10 ); //As importing staff user so no need to generate lead on CRM so don't generating lead on CRM
							$random_password = wp_generate_password( $length = 12, $include_standard_special_chars = false );
							//Create and register user in portal
							$user_id = wp_create_user( $staff_user['user_login'], $random_password, $staff_user['user_email'] );
							if ( ! ($user_id instanceof WP_Error) ) {
								$state_id = (isset( $result->address1_stateorprovince ) && ( ! empty( $result->address1_stateorprovince ))) ? $db_operations->get_state_id_by_code( $result->address1_stateorprovince ) : NULL;
								//Prepare staff user's other details
								$staff_user_data = array();
								$staff_user_data['user_login'] = $user_login;
								$staff_user_data['user_nicename'] = substr( trim( $user_login ), 0, 50 );
								$staff_user_data['user_email'] = trim( $staff_user['user_email'] );
								$staff_user_data['user_url'] = '';
								$staff_user_data['user_activation_key'] = NULL;
								$staff_user_data['user_status'] = 0;
								$staff_user_data['preferred_form'] = NULL;
								$staff_user_data['user_type'] = 'staff';
								$staff_user_data['display_name'] = (isset( $result->fullname ) && ( ! empty( $result->fullname ))) ? substr( trim( $result->fullname ), 0, 249 ) : '';
								$staff_user_data['salutaions'] = NULL;
								$staff_user_data['first_name'] = (isset( $result->firstname ) && ( ! empty( $result->firstname ))) ? substr( trim( $result->firstname ), 0, 254 ) : '';
								$staff_user_data['last_name'] = (isset( $result->lastname ) && ( ! empty( $result->lastname ))) ? substr( trim( $result->lastname ), 0, 254 ) : '';
								$staff_user_data['website_url'] = NULL;
								$staff_user_data['zipcode'] = (isset( $result->address1_postalcode ) && ( ! empty( $result->address1_postalcode ))) ? wp_slash( trim( $result->address1_postalcode ) ) : '';
								$staff_user_data['city'] = (isset( $result->address1_city ) && ( ! empty( $result->address1_city ))) ? wp_slash( trim( $result->address1_city ) ) : '';
								$staff_user_data['state'] = $state_id;
								$staff_user_data['created_by'] = NULL;
								$staff_user_data['company_name'] = NULL;
								$staff_user_data['title'] = NULL;
								$staff_user_data['address'] = NULL;
								$staff_user_data['phone'] = (isset( $result->address1_telephone1 ) && ( ! empty( $result->address1_telephone1 ))) ? wp_slash( trim( $result->address1_telephone1 ) ) : '';
								$staff_user_data['fax'] = (isset( $result->address1_fax ) && ( ! empty( $result->address1_fax ))) ? wp_slash( trim( $result->address1_fax ) ) : '';
								$staff_user_data['created_on'] = (isset( $result->createdon ) && ( ! empty( $result->createdon )) && ( ! empty( $result->createdon->FormattedValue ))) ? date( "Y-m-d H:i:s", strtotime( $result->createdon->FormattedValue ) ) : NULL;
								$staff_user_data['modified_on'] = (isset( $result->modifiedon ) && ( ! empty( $result->modifiedon )) && ( ! empty( $result->modifiedon->FormattedValue ))) ? date( "Y-m-d H:i:s", strtotime( $result->modifiedon->FormattedValue ) ) : NULL;
								$staff_user_data['crm_lead_id'] = NULL;
								$staff_user_data['company_id'] = 0;
								$staff_user_data['crm_id'] = trim( $result->systemuserid );
								$staff_user_data['crm_pull'] = 1;
								$staff_user_data['company_crm_id'] = NULL;
								//Update staff user's other details
								$wpdb->update( $wpdb->prefix . "users", $staff_user_data, array( 'id' => $user_id ) );
								//Set user role to staff
								$user = new WP_User( $user_id );
								$user->remove_role( 'new_user' );
								$user->set_role( 'staff' );
								$user->add_cap( 'list_users' );
								echo "Success : User imported in to portal for CRM user:" . $result->fullname . ".<br />\n";
								$totalRecordsCreated ++;
							} else {
								$totalRecordsNotCreated ++;
								echo "Error : User not imported in to portal for CRM user:" . $result->fullname . ". Error message :" . $user_id->get_error_message( $user_id->get_error_code() ) . ".<br />\n";
							}
						} else {
							$totalRecordsNotCreated ++;
							echo "Error : User not imported in to portal for CRM user :" . $result->fullname . ". Error message :User already exist having same email address.:" . $user_email . "<br />\n";
						}
					} else {
						$totalRecordsNotCreated ++;
						echo "Error : User not imported in to portal for CRM user :" . $result->fullname . ". Error message :Due to internalemailaddress or domainname not found.<br />\n";
					}
				}
			} else {
				$totalRecordsNotCreated ++;
				echo "Error : User not imported in to portal for CRM user :" . $result->fullname . ". Error message :Due to internalemailaddress or domainname not found.<br />\n";
			}
		} catch ( Exception $e ) {
			$totalRecordsNotCreated ++;
		}
		$start ++;
	} while ( $resultsfromcrm->MoreRecords == 1 );
	if ( $cron_output ) {
		echo "Fetched Records " . $totalRecordsFetched . "<br />\n";
		echo "Inserted Records " . $totalRecordsCreated . "<br />\n";
		echo "Not Inserted Records " . $totalRecordsNotCreated . "<br />\n";
	}
}

function pullStaffForAdmin() {
    global $wpdb;
    global $cron_output;
    $start = '1';
    $limit = '5';
    $haverecords = true;
    $totalRecordsFetched = $totalRecordsCreated = $totalRecordsNotCreated = 0;
    $db_operations = DbOperations::getInstance();
    $crm_operations_obj = getCrmConnection();
    $userArr= [];
    $crm_operations_obj->crmConnector->setMaximumRecords(100);
    do {
        try {
            $resultsfromcrm = $crm_operations_obj->getCrmEntityDetails( 'systemuser', null, 'list', null, $start, 100 );
            $totalRecordsFetched = $resultsfromcrm->TotalRecordCount;
            $start ++;
            if ( count( $resultsfromcrm ) > 0 ) {
                foreach ( $resultsfromcrm->Entities as $result_key => $result ) {
                    if ( (isset( $result->internalemailaddress ) && ! empty( $result->internalemailaddress )) && (isset( $result->domainname ) && ! empty( $result->domainname )) ) {
                        $user_login = (isset( $result->domainname ) && ( ! empty( $result->domainname ))) ? wp_slash( trim( stristr( $result->domainname, '\\' ), '\\' ) ) : '';
                        $user_email = (isset( $result->internalemailaddress ) && ( ! empty( $result->internalemailaddress ))) ? wp_slash( trim( $result->internalemailaddress ) ) : '';
                        $is_staff_exists = false;
                        $sql = $wpdb->prepare( 'select id from ' . $wpdb->prefix . 'users where user_email = %s and user_type = "staff"', $user_email );
                        $user_exist_result = $wpdb->get_row( $sql );
                        if ( $wpdb->num_rows > 0 ) {
                            $is_staff_exists = true;
                        }
                        //In case of staff user does not exists in the portal then import that user into portal
                        if ( ! $is_staff_exists ) {
                            $staff_user['user_login'] = $user_login;
                            $staff_user['user_email'] = $user_email;
                            remove_action( 'user_register', 'crm_user_register', 20 ); //As importing staff user so no need to generate lead on CRM so don't generating lead on CRM
                            remove_filter( 'user_contactmethods', 'remove_password_from_profile', 10 ); //As importing staff user so no need to generate lead on CRM so don't generating lead on CRM
                            $random_password = wp_generate_password( $length = 12, $include_standard_special_chars = false );
                            //Create and register user in portal
                            $user_id = wp_create_user( $staff_user['user_login'], $random_password, $staff_user['user_email'] );
                            if ( ! ($user_id instanceof WP_Error) ) {
                                $state_id = (isset( $result->address1_stateorprovince ) && ( ! empty( $result->address1_stateorprovince ))) ? $db_operations->get_state_id_by_code( $result->address1_stateorprovince ) : NULL;
                                //Prepare staff user's other details
                                $staff_user_data = array();
                                $staff_user_data['user_login'] = $user_login;
                                $staff_user_data['user_nicename'] = substr( trim( $user_login ), 0, 50 );
                                $staff_user_data['user_email'] = trim( $staff_user['user_email'] );
                                $staff_user_data['user_url'] = '';
                                $staff_user_data['user_activation_key'] = NULL;
                                $staff_user_data['user_status'] = 0;
                                $staff_user_data['preferred_form'] = NULL;
                                $staff_user_data['user_type'] = 'staff';
                                $staff_user_data['display_name'] = (isset( $result->fullname ) && ( ! empty( $result->fullname ))) ? substr( trim( $result->fullname ), 0, 249 ) : '';
                                $staff_user_data['salutaions'] = NULL;
                                $staff_user_data['first_name'] = (isset( $result->firstname ) && ( ! empty( $result->firstname ))) ? substr( trim( $result->firstname ), 0, 254 ) : '';
                                $staff_user_data['last_name'] = (isset( $result->lastname ) && ( ! empty( $result->lastname ))) ? substr( trim( $result->lastname ), 0, 254 ) : '';
                                $staff_user_data['website_url'] = NULL;
                                $staff_user_data['zipcode'] = (isset( $result->address1_postalcode ) && ( ! empty( $result->address1_postalcode ))) ? wp_slash( trim( $result->address1_postalcode ) ) : '';
                                $staff_user_data['city'] = (isset( $result->address1_city ) && ( ! empty( $result->address1_city ))) ? wp_slash( trim( $result->address1_city ) ) : '';
                                $staff_user_data['state'] = $state_id;
                                $staff_user_data['created_by'] = NULL;
                                $staff_user_data['company_name'] = NULL;
                                $staff_user_data['title'] = NULL;
                                $staff_user_data['address'] = NULL;
                                $staff_user_data['phone'] = (isset( $result->address1_telephone1 ) && ( ! empty( $result->address1_telephone1 ))) ? wp_slash( trim( $result->address1_telephone1 ) ) : '';
                                $staff_user_data['fax'] = (isset( $result->address1_fax ) && ( ! empty( $result->address1_fax ))) ? wp_slash( trim( $result->address1_fax ) ) : '';
                                $staff_user_data['created_on'] = (isset( $result->createdon ) && ( ! empty( $result->createdon )) && ( ! empty( $result->createdon->FormattedValue ))) ? date( "Y-m-d H:i:s", strtotime( $result->createdon->FormattedValue ) ) : NULL;
                                $staff_user_data['modified_on'] = (isset( $result->modifiedon ) && ( ! empty( $result->modifiedon )) && ( ! empty( $result->modifiedon->FormattedValue ))) ? date( "Y-m-d H:i:s", strtotime( $result->modifiedon->FormattedValue ) ) : NULL;
                                $staff_user_data['crm_lead_id'] = NULL;
                                $staff_user_data['company_id'] = 0;
                                $staff_user_data['crm_id'] = trim( $result->systemuserid );
                                $staff_user_data['crm_pull'] = 1;
                                $staff_user_data['company_crm_id'] = NULL;
                                //Update staff user's other details
                                $wpdb->update( $wpdb->prefix . "users", $staff_user_data, array( 'id' => $user_id ) );
                                //Set user role to staff
                                $user = new WP_User( $user_id );
                                $user->remove_role( 'new_user' );
                                $user->set_role( 'staff' );
                                $user->add_cap( 'list_users' );
                                $userArr[] = $user_id;
                                //echo "Success : User imported in to portal for CRM user:" . $result->fullname . ".<br />\n";
                                $totalRecordsCreated ++;
                            } else {
                                $totalRecordsNotCreated ++;
                            }
                        } else {
                            $totalRecordsNotCreated ++;
                        }
                    } else {
                        $totalRecordsNotCreated ++;
                    }
                }
            } else {
                $totalRecordsNotCreated ++;
            }
        } catch ( Exception $e ) {
            $totalRecordsNotCreated ++;
        }
        $start ++;
    } while ( $resultsfromcrm->MoreRecords == 1 );
    $userArr = implode( ',', $userArr );
    echo home_url() . '/wp-admin/users.php' . '?data=' . base64_encode( $userArr );
    //exit;
    wp_redirect( home_url() . '/wp-admin/users.php' . '?data=' . base64_encode( $userArr ) );
    //echo json_encode( ['userEmail' => $userArr, 'totalInserted' => $totalRecordsCreated ] );
    exit;
}

/**
 * Delete all lead on crm
 * @param integer $dd, date
 * @param integer $mm, month
 * @param integer $yyyy, year in 4 digit format
 */
function delete_all_lead_from_crm_by_created_date( $dd, $mm, $yyyy ) {
	global $wpdb;
	global $cron_output;
	$crm_operations_obj = getCrmConnection();
	//$crm_operations_obj->crmConnector->setMaximumRecords(1000);
	$start = '1';
	$limit = '1000';
	$haverecords = true;
	$totalRecordsFetched = $totalRecordsDeleted = $totalRecordsNotDeleted = 0;
	$where = array();
	do {
		if ( isset( $where ) && ! empty( $where ) ) {
			unset( $where );
			$where = array();
		}
		$created_date = trim( $mm . '/' . $dd . '/' . $yyyy );
		$where = array( 'type' => 'and' );
		$where['conditions'][] = array( 'attribute' => 'createdon', 'operator' => 'on-or-after', 'value' => $created_date );
		//Created by = "IAS Portal"
		$where['conditions'][] = array( 'attribute' => 'createdby', 'operator' => 'not-null' );
		$where['conditions'][] = array( 'attribute' => 'emailaddress1', 'operator' => 'null' );
		$where['conditions']['_linked']['systemuser'] = array( 'type' => 'and', 'conditions' =>
			array(
				array( 'attribute' => 'firstname', 'operator' => 'like', 'value' => "%IAS%" ), //Created by = "IAS Portal"
			)
		);
		//Fetch leads from CRM to be deleted on CRM
		$resultsfromcrm = $crm_operations_obj->getCrmEntityDetails( 'lead', $where, 'list', null, $start, $limit );
		$totalRecordsFetched = $resultsfromcrm->TotalRecordCount;
		;
		$start ++;
		foreach ( $resultsfromcrm->Entities as $result_key => $result ) {
			try {
				if ( isset( $result ) && ( ! empty( $result )) ) {
					//Prepare lead object to be deleted on CRM
					$lead_obj = $crm_operations_obj->getEntityObj( "lead" );
					$lead_obj->ID = $result->leadid;
					$lead_obj->leadid = $result->leadid;
					//Delete lead object on CRM
					$lead_deletion_result = $crm_operations_obj->crmConnector->delete( $lead_obj );
					if ( $lead_deletion_result == false ) {
						$totalRecordsDeleted ++;
					} else {
						$totalRecordsNotDeleted ++;
					}
				}
			} catch ( Exception $e ) {
				$totalRecordsNotDeleted ++;
			}
		}
		$start ++;
	} while ( $resultsfromcrm->MoreRecords == 1 );
	if ( $cron_output ) {
		echo "Fetched Records " . $totalRecordsFetched . "<br />\n";
		echo "Deleted Records " . $totalRecordsDeleted . "<br />\n";
		echo "Not Deleted Records " . $totalRecordsNotDeleted . "<br />\n";
	}
}

function fetch_crm_certificates_contact_mapping() {
	set_time_limit( 0 );
	ini_set( 'max_execution_time', 0 );
	global $wpdb, $wp_hasher;
	$crm_operations_obj = getCrmConnection();
	$start = 1;
	$limit = 1000;
	$where = array( 'type' => 'and' );
	/* to get aacrediated only */
	$where['conditions'][] = array( 'attribute' => 'new_certificatestatus', 'operator' => 'eq', 'value' => '100000000' );
	/* to get active only */
	$where['conditions'][] = array( 'attribute' => 'statuscode', 'operator' => 'eq', 'value' => '1' );
	do {
		$resultsfromcrm = $crm_operations_obj->getCrmEntityDetails( 'new_certificate', $where, 'email', null, $start, $limit );
		if ( $resultsfromcrm->Count ) {
			foreach ( $resultsfromcrm->Entities as $entity ) {
				if ( isset( $entity->new_technicalcontactid ) ) {
					$wpdb->insert( $wpdb->prefix . 'certificate_contact_mapping', array( 'certificate_crm_id' => $entity->new_certificateid, 'contact_crm_id' => $entity->new_technicalcontactid->Id ) );
				}
				if ( isset( $entity->new_billingcontactid ) ) {
					$wpdb->insert( $wpdb->prefix . 'certificate_contact_mapping', array( 'certificate_crm_id' => $entity->new_certificateid, 'contact_crm_id' => $entity->new_billingcontactid->Id ) );
				}
				if ( isset( $entity->new_legalcontactid ) ) {
					$wpdb->insert( $wpdb->prefix . 'certificate_contact_mapping', array( 'certificate_crm_id' => $entity->new_certificateid, 'contact_crm_id' => $entity->new_legalcontactid->Id ) );
				}
			}
		}
		$start ++;
	} while ( $resultsfromcrm->MoreRecords );
}

function send_welcome_mail() {
	set_time_limit( 0 );
	ini_set( 'max_execution_time', 0 );
	global $wpdb, $wp_hasher;
	$max_limit = isset( $_REQUEST['to'] ) ? $_REQUEST['to'] : 100;
	$errors = new WP_Error();
	$bnfw = BNFW::factory();
	if ( $bnfw->notifier->notification_exists( "send-password-notification-for-customer" ) ) {
		$notifications = $bnfw->notifier->get_notifications( "send-password-notification-for-customer" );
		$notification = $notifications[0];
		$setting = $bnfw->notifier->read_settings( $notification->ID );
		$subjectstaff = $setting['subject'];
		$message = $setting['message'];
		if ( isset( $_REQUEST['all'] ) ) {
			$sql = $wpdb->prepare( "SELECT ID,user_login,user_email,first_name FROM {$wpdb->users} WHERE user_type in (%s,%s) AND user_login!= %s AND is_notified = %d AND crm_id in ( SELECT distinct(contact_crm_id) FROM {$wpdb->prefix}certificate_contact_mapping ) ", 'contact', 'admin', 0 );
		} else {
			$sql = $wpdb->prepare( "SELECT ID,user_login,user_email,first_name FROM {$wpdb->users} WHERE user_type in (%s,%s) AND user_login!= %s AND is_notified = %d AND crm_id in ( SELECT distinct(contact_crm_id) FROM {$wpdb->prefix}certificate_contact_mapping ) LIMIT %d ", 'contact', 'admin', 0, $max_limit );
		}
		$result = $wpdb->get_results( $sql, ARRAY_A );
		if ( isset( $result ) && ! empty( $result ) ) {
			if ( ! isset( $_REQUEST['send_emails'] ) ) {
				echo '<pre>';
				print_r( $result );
				exit;
			}
			foreach ( $result as $users ) {
				if ( ! empty( $users['user_email'] ) && ! filter_var( $users['user_email'], FILTER_VALIDATE_EMAIL ) === false ) {
					$user_login = $users['user_login'];
					// Generate something random for a password reset key.
					$key = wp_generate_password( 20, false );
					/**
					 * Fires when a password reset key is generated.
					 *
					 * @since 2.5.0
					 *
					 * @param string $user_login The username for the user.
					 * @param string $key        The generated password reset key.
					 */
					// Now insert the key, hashed, into the DB.
					if ( empty( $wp_hasher ) ) {
						require_once ABSPATH . WPINC . '/class-phpass.php';
						$wp_hasher = new PasswordHash( 8, true );
					}
					$hashed = $wp_hasher->HashPassword( $key );
					$wpdb->update( $wpdb->users, array( 'user_activation_key' => $hashed ), array( 'user_login' => $user_login ) );
					$url = network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user_login ), 'login' );
					$email_content = str_replace( '[firstname]', ucwords( $users['first_name'] ), $message );
					$email_content = str_replace( '[email]', $users['user_email'], $email_content );
					$email_content = str_replace( '[link]', $url, $email_content );
					if ( wp_mail( $users['user_email'], $subjectstaff, wpautop( $email_content ) ) ) {
						$wpdb->update( $wpdb->users, array( 'is_notified' => 1 ), array( 'ID' => $users['ID'] ) );
					}
				}
			}
		}
	}
}

/* One reminder needs to go out 30 days after the assessment end date to the customers if any unresolved CAR. */

function unresolved_car_reminder() {
	set_time_limit( 0 );
	ini_set( 'max_execution_time', 0 );
	global $wpdb;

	$query = $wpdb->prepare( "SELECT cert.id as certid, max(adp.end_date) as end_date, usr.user_email, usr.first_name, usr.last_name, asm.id, adp.id as aid, asm.name "
		. "FROM {$wpdb->prefix}assessment_activity aa "
		. "join {$wpdb->prefix}assessment_dates_proposed adp on aa.id = adp.assessment_activity_id "
		. "join {$wpdb->prefix}assessments asm on asm.id = aa.assessment_id "
		. "join {$wpdb->prefix}certificate cert on asm.certificate_id = cert.certificate_crm_id "
		. "join {$wpdb->prefix}certificate_contact_mapping ccm on cert.id = ccm.certificate_id "
		. "join {$wpdb->prefix}users usr on usr.ID = ccm.user_id "
		. "join {$wpdb->prefix}agenda agd on agd.assessment_id = aa.assessment_id "
		. "join {$wpdb->prefix}agenda_checklist_data acd on acd.agenda_id = agd.id "
		. "join {$wpdb->prefix}checklist_data_carcon cdc on cdc.agenda_checklist_data_id = acd.id "
		. "where asm.assessment_stage != %s and adp.end_date != %s and adp.status = %s and usr.user_type = %s and cdc.status = '1' "
		. ' group by ccm.user_id, asm.id order by adp.end_date asc', '100000000', '0000-00-00 00:00:00', '2', 'contact' );

	$carcon_result = $wpdb->get_results( $query );

	$new_res = array();
	foreach ( $carcon_result as $cr ) {
		if ( ! isset( $new_res["{$cr->id}|{$cr->user_email}"] ) && date( 'Y-m-d', strtotime( '+30 days', strtotime( $cr->end_date ) ) ) == date( 'Y-m-d' ) ) {
			$new_res["{$cr->id}|{$cr->user_email}"]['end_date'] = $cr->end_date;
			$new_res["{$cr->id}|{$cr->user_email}"]['first_name'] = $cr->first_name;
			$new_res["{$cr->id}|{$cr->user_email}"]['last_name'] = $cr->last_name;
			$new_res["{$cr->id}|{$cr->user_email}"]['user_email'] = $cr->user_email;
			$new_res["{$cr->id}|{$cr->user_email}"]['asm_id'] = $cr->id;
			$new_res["{$cr->id}|{$cr->user_email}"]['name'] = $cr->name;
		}
	}
	$bnfw = BNFW::factory();
	if ( $bnfw->notifier->notification_exists( 'unresolved-car-reminder' ) ) {
		$notifications = $bnfw->notifier->get_notifications( 'unresolved-car-reminder' );
		$notification = $notifications[0];
		$setting = $bnfw->notifier->read_settings( $notification->ID );

		foreach ( $new_res as $cr ) {
			$link = get_permalink( get_page_by_path( 'assessment-details' ) ) . '?key=' . get_encoded_url_string( 'asmid=' . $cr['asm_id'] ) . '#cars';
			$subjectcustomer = $setting['subject'];
			$message = $setting['message'];
			$subjectcustomer = str_replace( '[assessment-name]', $cr['name'], $subjectcustomer );
			$message = str_replace( '[Assessment Name]', stripslashes( $cr['name'] ), $message );
			$message = str_replace( '[Firstname]', ucwords( stripslashes( $cr['first_name'] ) ), $message );
			$message = str_replace( '[Lastname]', ucwords( stripslashes( $cr['last_name'] ) ), $message );
			$message = str_replace( '[link]', $link, $message );
			wp_mail( $cr['user_email'], $subjectcustomer, wpautop( $message ) );
		}
	}
}

function assign_staff() {
    global $wpdb;
    $tablename = $wpdb->prefix . 'program_user_association';
    $userid = isset( $_REQUEST['userid'] ) ? $_REQUEST['userid'] : '';
    if($userid == '') {
        echo "Please add query parameter 'userid'"; die;
    }
    else {
        $wpdb->query( $wpdb->prepare( "DELETE FROM " . $tablename . " where user_id=%d", $userid  ) );

        $results = $wpdb->get_results( $wpdb->prepare( "SELECT `id` FROM `wp_programs` where %d" , 1 ) );
        foreach ( $results as $result ) {
            $wpdb->query( $wpdb->prepare( "INSERT INTO `wp_program_user_association` (`program_id`, `user_id`, `is_staff`, `is_pc`, `is_dmb`) VALUES ( %d ,%d,%s,%s,%s) " , $result->id, $userid,1,1,1 )) ;
        }
    }
    die('success');
}

function staff_notification_association() {
    global $wpdb;
    $notification_type_id['61'] = array(65,93);
    $notification_type_id['85'] = array(96,97,86);
    $notification_type_id['78'] = array(81,82,83,84,92,94);

    $is_phase1 = isset( $_REQUEST['is_phase1'] ) ? $_REQUEST['is_phase1'] : 0;
    if($is_phase1 == 1)
        $notification_type_id['66'] = array(72,77,74,67,95,68,91);

    $user_ID = get_current_user_id();
    $sub_notification_type_id = isset( $_REQUEST['sub_notification_type_id'] ) ? $_REQUEST['sub_notification_type_id'] : '';
    $userid = isset( $_REQUEST['userid'] ) ? $_REQUEST['userid'] : '';
    $tablename = $wpdb->prefix . 'staff_notification_associations';
    if($userid == '') {
        echo "Please add query parameter 'userid'"; die;
    } else {
        $delete_where = array(
			'user_id' => $userid
		);
        $wpdb->delete( $tablename, $delete_where );
        foreach($notification_type_id as $key => $val){
            foreach($val as $v){
                if($key == '61' && $v == '65') {
                    $program_type = NULL ;
                    $insert_data = array(
                            'user_id' => $userid,
                            'notification_type_id' => $key,
                            'subnotification_type_id' => $v,
                            'createdby' => $user_ID,
                            'createdon' => date( 'Y-m-d h:i:s' ),
                            'modifiedby' => $user_ID,
                    );
                    $query_flag = $wpdb->insert( $wpdb->prefix . 'staff_notification_associations', $insert_data );
                } else {

                    $results = $wpdb->get_results( $wpdb->prepare( "SELECT `id` FROM `wp_programs` where %d" , 1 ) );
                    foreach ( $results as $result ) {
                        $insert_data = array(
                                'user_id' => $userid,
                                'notification_type_id' => $key,
                                'subnotification_type_id' => $v,
                                'createdby' => $user_ID,
                                'createdon' => date( 'Y-m-d h:i:s' ),
                                'modifiedby' => $user_ID,
                                'program_id' => $result->id
                        );

                        $query_flag = $wpdb->insert( $wpdb->prefix . 'staff_notification_associations', $insert_data );
                    }
                }
            }
        }
        die('success');
    }
}

	/* One reminder needs to go out, If the Assessment Team Member (assessor) didn't acknowledge even after 3 days of his/her assignment to the team. */

	function reminder_to_acknowledge_assessment_assignment() {
		global $wpdb;

		$three_day_back = date( 'Y-m-d', strtotime( '-3 days' ) ) ;
		$start_date = $three_day_back . " 00:00:00" ;
		$end_date = $three_day_back . " 23:59:59" ;

		$query = $wpdb->prepare( "SELECT aa.assessment_id, assessment.name ,aa.assessor_id, user.first_name, user.user_email , aa.response FROM wp_assessment_assessor as aa

LEFT JOIN wp_assessments as assessment ON ( assessment.id = aa.assessment_id )

LEFT JOIN  wp_users as user on (user.ID = aa.assessor_id) WHERE ( aa.createdon BETWEEN %s AND %s ) AND aa.response = %s ", $start_date , $end_date , '0' );
		$assessment_details = $wpdb->get_results( $query );
		$bnfw = BNFW::factory();
		if ( $bnfw->notifier->notification_exists( 'reminder-to-acknowledge-assessment-assignment' ) ) {
			$notifications = $bnfw->notifier->get_notifications( 'reminder-to-acknowledge-assessment-assignment' );
			$notification = $notifications[0];
			$setting = $bnfw->notifier->read_settings( $notification->ID );

			foreach ( $assessment_details as $assess_detail ) {
				$link = get_permalink( get_page_by_path( 'assessment-details' ) ) . '?key=' . get_encoded_url_string( 'asmid=' . $assess_detail->assessment_id );
				$subjectcustomer = $setting['subject'];
				$message = $setting['message'];
				$subjectcustomer = str_replace( '[assessment-name]', $assess_detail->name, $subjectcustomer );
				$message = str_replace( '[firstname]', ucwords( stripslashes( $assess_detail->first_name ) ), $message );
				$message = str_replace( '[assessment-name]', $assess_detail->name, $message );
				$message = str_replace( '[link]', $link, $message );
				wp_mail( $assess_detail->user_email, $subjectcustomer, wpautop( $message ) );
			}
		}
	}

ini_set( 'max_execution_time', $default_execution_time );
ini_set( 'error_reporting', $default_error_reporting );
exit( 0 );
