<?php
require_once( dirname( __FILE__ ) . '/wp-load.php' );
require_once( dirname( __FILE__ ) . '/wp-content/plugins/crm-connector/document_upload_cron.php' );
require_once( dirname( __FILE__ ) . '/wp-content/plugins/crm-connector/create_closed_activity_cron.php' );
require_once( dirname( __FILE__ ) . '/wp-content/plugins/crm-connector/crm-functions.php' );
require_once ( dirname( __FILE__ ) . '/wp-content/plugins/crm-connector/DynamicsCRM2011.php' );

global $wpdb;
$crmOperationsObj = getCrmConnection();
$quotations = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}users WHERE ( display_name is null or display_name = '') AND user_type = 'contact' ORDER by created_on DESC LIMIT 0,3;" );
foreach( $quotations as $con ) {
    $crm_filter_condition = array( 'type' => 'and' );
    $crm_filter_condition['conditions'][] = array( 'attribute' => 'contactid', 'operator' => 'eq', 'value' => $con->crm_id );
    try{
        $contact = $crmOperationsObj->getCrmEntityDetails( 'contact', $crm_filter_condition, 'list', null, 1, 1 );
        $contact = ! empty( $contact ) ? $contact->Entities[0] : NULL;
        if( $contact ) {
            $firstName = $contact->firstname;
            $lastName = $contact->lastname;
            $fullname = $contact->fullname;
            $fullname = empty( $fullname ) ? $firstName . ' ' . $lastName : $fullname;
            if( ! empty( $firstName ) || ! empty( $lastName ) ) {
                $wpdb->update( "{$wpdb->prefix}users", array( 'first_name' => $firstName, 'last_name' => $lastName, 'display_name' => $fullname ), array( 'ID' => $con->ID ) );
            } else {
                try {
                    $data = $crmOperationsObj->generateChangeHistory( 'contact',$con->crm_id );
                    foreach($data->AuditDetails as $rec) {
                        $metaData = $rec->Values;
                        $phone = ( empty( $metaData->telephone1->NewValue ) ) ? $metaData->telephone1->OldValue : $metaData->telephone1->NewValue;
                        $salutation = ( empty( $metaData->salutation->NewValue ) ) ? $metaData->salutation->OldValue : $metaData->salutation->NewValue;
                        $firstname = ( empty( $metaData->firstname->NewValue ) ) ? $metaData->firstname->OldValue : $metaData->firstname->NewValue;
                        $lastname = ( empty( $metaData->lastname->NewValue ) ) ? $metaData->lastname->OldValue : $metaData->lastname->NewValue;
                        $fullname = ( empty( $metaData->fullname->NewValue ) ) ? $metaData->fullname->OldValue : $metaData->fullname->NewValue;
                        $contact_obj = $crmOperationsObj->getEntityObj( 'contact' );
                        $contact_obj->ID = $con->crm_id;
                        $contact_obj->firstname = $firstname;
                        $contact_obj->lastname = $lastname;
                        if( ! empty( $firstname ) && ! empty( $lastname ) ) {
                            try {
                                $crmOperationsObj->updateEntity( $contact_obj );
                            } catch ( Exception $e ) {
                                echo $e->getMessage();
                            }
                            $wpdb->update( "{$wpdb->prefix}users", array( 'first_name' => $firstname, 'last_name' => $lastname, 'display_name' => $fullname ), array( 'ID' => $con->ID ) );
                            continue;
                        }
                    }
                } catch ( Exception $e ) {
                    echo 'An error occurred while trying to get the audit history!!!';
                }
            }
        }
    } catch( Exception $e ){
        echo 'An error occurred!!!';
    }
}
