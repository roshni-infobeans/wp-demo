<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
if ( ! defined( 'ABSPATH' ) ) {
	/** Set up WordPress environment */
	require_once( dirname( __FILE__ ) . '/wp-load.php' );
}
$encoded_key = isset( $_REQUEST['key'] ) ? $_REQUEST['key'] : "";
$decoded_keys = get_decoded_url_string( $encoded_key );
$shr_file_url = isset( $decoded_keys['shr_file_url'] ) ? $decoded_keys['shr_file_url'] : "";
$shr_file_name = isset( $decoded_keys['file_name'] ) ? $decoded_keys['file_name'] : "";
$from_sharepoint = isset( $decoded_keys['from'] ) ? $decoded_keys['from'] : "";
$fileId = isset( $decoded_keys['file_id'] ) ? $decoded_keys['file_id'] : "";
$user_id = isset( $decoded_keys['user_id'] ) ? $decoded_keys['user_id'] : "";
$type = isset( $decoded_keys['type'] ) ? $decoded_keys['type'] : "";
$assessment_id = isset( $decoded_keys['assessment_id'] ) ? $decoded_keys['assessment_id'] : 0;
$agenda_id = isset( $decoded_keys['agenda_id'] ) ? $decoded_keys['agenda_id'] : 0;
$allowed_download = checkAttachmentAuthentication( $fileId );

if ( $allowed_download != 1 ) {
	$err = 'Sorry, the file you are requesting is unavailable.';
	echo $err;
	exit( 0 );
}

if ( ! empty( $type ) && $type == 'assessment_doc' ) {
	$current_user_id = get_current_user_id();
	if ( $user_id != $current_user_id ) {
		$err = 'Sorry, the file you are requesting is unavailable.';
		echo $err;
		exit( 0 );
	}
}

/**
 * Sharepoint file download
 */
if ( $from_sharepoint == 'sharepoint' && ! empty( $shr_file_url ) ) {
	download_sharepoint_document( $shr_file_url, $shr_file_name );
}

if ( ! empty( $fileId ) ) {
	getfile_callback( $fileId );
}

if ( ! empty( $user_id ) && ! empty( $type ) ) {
	downloadCertZip( $user_id, $type, $assessment_id, $agenda_id );
}
getzipurl_callback();

function getzipurl_callback() {

	global $wpdb;
	//$program_id = isset($_REQUEST['programId'])?$_REQUEST['programId']:'';
	//$program_name = isset($_REQUEST['programName'])?$_REQUEST['programName']:'';
	$encoded_key = isset( $_REQUEST['key'] ) ? $_REQUEST['key'] : "";
	$decoded_keys = get_decoded_url_string( $encoded_key );
	$program_id = isset( $decoded_keys['programId'] ) ? $decoded_keys['programId'] : "";
	$program_name = isset( $decoded_keys['programName'] ) ? $decoded_keys['programName'] : "";

	if ( ! empty( $program_id ) ) {
		$queryDocId = "select doc_id from {$wpdb->prefix}program_docs where program_id = " . $program_id; //.$appl_selected;
		$resultDocId = $wpdb->get_results( $queryDocId );
	}
	if ( ! empty( $resultDocId ) ) {

		foreach ( $resultDocId as $docId ) {
			$allDocId .= $docId->doc_id;
			$allDocId .= ",";
		}
		$allDocId = rtrim( $allDocId, "," );

		$query = "select meta_value from {$wpdb->prefix}postmeta where post_id IN (" . $allDocId . ")";
		remove_filter( 'upload_dir', 'mgmt_third_party' );
		$resultDocPath = $wpdb->get_results( $query );
		$uploads = wp_upload_dir();
		$file_names = array();
		if ( isset( $resultDocPath[0]->meta_value ) && $resultDocPath[0]->meta_value != '' ) {

			foreach ( $resultDocPath as $resultDocPathValues ) {
				$path_parts = pathinfo( $uploads['baseurl'] . "/" . $resultDocPathValues->meta_value );
				$ext = $path_parts['extension'];
				$fileName = $path_parts['filename']; // since PHP 5.2.0
				$fileWithExt = $fileName . "." . $ext;
				$file_names[] = $resultDocPathValues->meta_value;
			}
			//Archive name
			$archive_file_name = trim( $program_name ) . '.zip';
			$file_path = $uploads['baseurl'] . "/" . $resultDocPath[0]->meta_value;
			$zip = zipFilesAndDownload( $file_names, $archive_file_name, $file_path );
		}
	}
}

function downloadCertZip( $user_id, $type, $assessment_id = 0, $agenda_id = 0 ) {
	global $wpdb;
	if ( ! empty( $user_id ) ) {
		$current_user_id = get_current_user_id();
		$current_user_role = get_current_user_role();
		if ( $user_id != $current_user_id && strtolower( $current_user_role ) != 'staff' ) {
			$err = 'Sorry, the file you are requesting is unavailable.';
			echo $err;
			exit( 0 );
		}
		$type_arr = array();
		$options['id'] = $user_id;
		if ( $type == 'assessment_agenda' && $assessment_id != 0 && $agenda_id != 0 ) {
			$assessment_doc = new IbAssessmentDocuments();
			$type_arr = $assessment_doc->getAgendaDocumentIds( $assessment_id, $agenda_id );
		} else if ( $type == 'assessment_pkg' && $assessment_id != 0 ) {
			$assessment_doc = new IbAssessmentDocuments();
			$type_arr = $assessment_doc->getAssessmentPackages( $assessment_id );
		} else {
			$assessor_details = IbAssessorMethods::get_assessor_details_view( $options );
			if ( $type == 'certificates' ) {
				$type_arr = json_decode( $assessor_details->assessor_certificates );
			} else if ( $type == 'affiliations' ) {
				$type_arr = json_decode( $assessor_details->assessor_affiliations );
			} else if ( $type == 'training_course' ) {
				$type_arr = json_decode( $assessor_details->assessor_trcourses );
			} else if ( $type == 'experience' ) {
				$type_arr = json_decode( $assessor_details->assessor_experience );
			} else if ( $type == 'education' ) {
				$type_arr = json_decode( $assessor_details->assessor_education );
			}
		}
	}
	if ( ! empty( $type_arr ) ) {
		$allDocId = '';
		foreach ( $type_arr as $type_ar ) {
			if ( ! empty( $type_ar->attach_id ) ) {
				$allDocId .= $type_ar->attach_id;
				$allDocId .= ",";
			}
		}
		$allDocId = rtrim( $allDocId, "," );
		$query = "select meta_value from " . $wpdb->prefix . "postmeta where post_id IN (" . $allDocId . ")";
		remove_filter( 'upload_dir', 'mgmt_third_party' );
		$resultDocPath = $wpdb->get_results( $query );
		$uploads = wp_upload_dir();
		$file_names = array();
		if ( isset( $resultDocPath[0]->meta_value ) && $resultDocPath[0]->meta_value != '' ) {
			foreach ( $resultDocPath as $resultDocPathValues ) {
				$path_parts = pathinfo( $uploads['baseurl'] . "/" . $resultDocPathValues->meta_value );
				$ext = $path_parts['extension'];
				$fileName = $path_parts['filename']; // since PHP 5.2.0
				$fileWithExt = $fileName . "." . $ext;
				$file_names[] = $resultDocPathValues->meta_value;
			}
			//Archive name
			$archive_file_name = trim( $type ) . '.zip';
			$file_path = $uploads['baseurl'] . "/" . $resultDocPath[0]->meta_value;
			$zip = zipFilesAndDownload( $file_names, $archive_file_name, $file_path );
		}
	}
}

function zipFilesAndDownload( $file_names, $archive_file_name, $file_path ) {
	$file = tempnam( "tmp", "zip" );
	$zip = new ZipArchive();
	$zip->open( $file, ZipArchive::OVERWRITE );
	remove_filter( 'upload_dir', 'mgmt_third_party' );
	$uploads = wp_upload_dir();
	foreach ( $file_names as $files ) {
		$path_parts = pathinfo( $uploads['baseurl'] . "/" . $files );
		$file_namesnew = $path_parts['basename'];
		$zip->addFile( $uploads['basedir'] . "/" . $files, $file_namesnew );
	}
	$zip->close();
	header( 'Content-Type: application/zip' );
	//   header('Content-Length: ' . filesize($file));
	header( 'Content-Disposition: attachment; filename="' . $archive_file_name . '"' );
	readfile( $file );
	unlink( $file );
}

/**
 * Function used to download single file.
 */
function getfile_callback( $fileId ) {
    if ( ! empty( $fileId ) ) {
        global $wpdb;
        $err = '';
        $uploads = wp_upload_dir();
        $upload_base_dir = $uploads['basedir'];
        $file_path = get_post_meta( $fileId, '_wp_attached_file', true );
        $file_parm = explode( '/', $file_path );
        $file_name = array_pop( (array_slice( $file_parm, -1 ) ) );
        $file_full_path = $upload_base_dir . '/' . $file_path;
        if ( file_exists( $file_full_path ) ) {
            if ( ! $file_name ) {
                $err = 'Sorry, the file you are requesting is unavailable.';
                echo $err;
            } else {
                $path = $file_full_path;
                if ( file_exists( $path ) && is_readable( $path ) ) {
                    $size = filesize( $path );
                    header( 'Content-Type: application/octet-stream' );
                    header( 'Content-Length: ' . $size );
                    header( 'Content-Disposition: attachment; filename="' . $file_name .'"');
                    readfile($path);
                } else {
                    echo $err;
                }
            }
        } else {
            $err = 'Sorry, the file you are requesting is unavailable.';
            echo $err;
        }
    } else {
        echo $err;
    }
}

/**
 *
 * @param type $shr_file_url
 * @param type $shr_file_name
 * Function used to download sharpoint file
 */
function download_sharepoint_document( $shr_file_url, $shr_file_name ) {
	$upload_dir = wp_upload_dir();
	$dir_base_path = $upload_dir['basedir'];
	$download_url = str_replace( " ", "%20", $shr_file_url );
	$shr_file_name = str_replace( " ", "-", $shr_file_name );
	$dir = $dir_base_path . '/sharepoint/' . $shr_file_name;
	if ( ! file_exists( $dir_base_path . '/sharepoint' ) ) {
		mkdir( $dir_base_path . '/sharepoint', 0777, true );
	}
	$fp = fopen( $dir, "w+" );
	$ch = curl_init( $download_url );
	curl_setopt( $ch, CURLOPT_FILE, $fp );
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
	curl_setopt( $ch, CURLOPT_VERBOSE, 1 );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch, CURLOPT_HTTPAUTH, CURLAUTH_NTLM );
	curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
	curl_setopt( $ch, CURLOPT_USERPWD, 'iasportal:Summer2015' );
	curl_setopt( $ch, CURLOPT_HEADER, 0 );
	$chresult = curl_exec( $ch );
	if ( 200 == curl_getinfo( $ch, CURLINFO_HTTP_CODE ) ) {
		fwrite( $fp, $chresult );
		fclose( $fp );
	}
	curl_close( $ch );

	if ( file_exists( $dir ) ) {

		if ( ! $shr_file_name ) {
			// if variable $filename is NULL or false display the message
			$err = 'Sorry, the file you are requesting is unavailable.';
			echo $err;
		} else {
			// define the path to your download folder plus assign the file name
			$path = $dir;
			// check that file exists and is readable
			if ( file_exists( $path ) && is_readable( $path ) ) {
				// get the file size and send the http headers
				$size = filesize( $path );
				header( 'Content-Type: application/octet-stream' );
				header( 'Content-Length: ' . $size );
				header( 'Content-Disposition: attachment; filename=' . $shr_file_name );
				$file = @ fopen( $path, 'rb' );
				if ( $file ) {
					// stream the file and exit the script when complete
					fpassthru( $file );
					@unlink( $path );
					exit;
				} else {
					echo $err;
				}
			} else {
				echo $err;
			}
			@unlink( $path );
		}
	} else {
		$err = 'Sorry, the file you are requesting is unavailable.';
		echo $err;
		@unlink( $path );
	}
}
