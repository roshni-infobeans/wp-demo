<?php

use Phinx\Migration\AbstractMigration;

class UpdateMenuItem extends AbstractMigration
{
    /**
     * Change Method.
     *
     * More information on this method is available here:
     * http://docs.phinx.org/en/latest/migrations.html#the-change-method
     *
     * Uncomment this method if you would like to use it.
     *
    public function change()
    {
    }
    */
    
    /**
     * Migrate Up.
     */
    public function up()
    {
        
        $sidebarPages = array(
			'user-dashboard',
			'ias-documents',
			'applications',
			'certificates',
			'invoices',
			'company',
			'contacts',
			'quotations',
			'edit-profile',
			'change-password',
			'gp-failed-transactions',
			'payment-listing',
		);

		$menuSlug = 'sidebar-logged-in-primary';
		$type = 'page';
		$createMenuObj = new CreateMenuOption();

		foreach ( $sidebarPages as $menu_item ) {
			$createMenuObj->delete_nav_menu_item( $menuSlug, $menu_item, $type );
		}
		sleep( 5 );

		$createMenuObj = new CreateMenuOption();

		$menuSlug = 'sidebar-logged-in-primary';
		$createMenuObj->get_nav_menu_items( $menuSlug );


		$sidebarPages = array(
			'dashboard' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Dashboard',
					'page_post_name' => 'user-dashboard',
					'menu_order' => 1,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'customer', 'contact', 'biling', 'modified', 'legal', 'technical', 'staff', 'assessor' ),
				'classes' => array( 'menu-my-dashboard' ),
			),
			'ias-document' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'IAS Documents',
					'page_post_name' => 'ias-documents',
					'menu_order' => 2,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'staff', 'assessor' ),
				'classes' => array( 'menu-my-iasdocument' ),
			),
			'applications' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'New Applications',
					'page_post_name' => 'applications',
					'menu_order' => 3,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'staff' ),
				'classes' => array( 'menu-my-application' ),
			),
			'certificates' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Certificates',
					'page_post_name' => 'certificates',
					'menu_order' => 4,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'customer', 'contact', 'biling', 'modified', 'legal', 'technical', 'staff', 'assessor' ),
				'classes' => array( 'menu-my-certificates' ),
			),
			'invoices' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Invoices',
					'page_post_name' => 'invoices',
					'menu_order' => 5,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'customer', 'contact', 'biling', 'modified', 'legal', 'technical', 'staff', 'assessor' ),
				'classes' => array( 'menu-my-invoices' ),
			),
			'quotations' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Quotations',
					'page_post_name' => 'quotations',
					'menu_order' => 6,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'customer', 'contact', 'biling', 'modified', 'legal', 'technical', 'staff', 'assessor' ),
				'classes' => array( 'menu-my-quotations' ),
			),
			'edit-profile' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'My Profile',
					'page_post_name' => 'edit-profile',
					'menu_order' => 7,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'customer', 'contact', 'biling', 'modified', 'legal', 'technical' ),
				'classes' => array( 'menu-my-editprofile' ),
			),
			'change-password' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Change Password',
					'page_post_name' => 'change-password',
					'menu_order' => 8,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'customer', 'contact', 'biling', 'modified', 'legal', 'technical' ),
				'classes' => array( 'menu-change-password' ),
			),
			'payment-listing' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Payment Listing',
					'page_post_name' => 'payment-listing',
					'menu_order' => 9,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'staff' ),
				'classes' => array( 'menu-my-paymentlist' ),
			),
		);

		foreach ( $sidebarPages as $pagemenu ) {
			$createMenuObj->register_my_menu( $pagemenu );
			$createMenuObj->update_logged_in_roles( $pagemenu['user_roles'], $pagemenu['menu_slug'], $update_roles = true, $pagemenu['menu_option']['page_post_name'], $pagemenu['menu_option']['type'] );
		}

		$term = term_exists( 'sidebar-logged-in-primary', 'nav_menu' );
		$var = get_option( 'theme_mods_responsive' );
		$var['nav_menu_locations']['sidebar-logged-in-primary'] = $term['term_taxonomy_id'];
		update_option( 'theme_mods_responsive', $var );
                
		$sidebarPages = array(
			'user-dashboard',
			'ias-documents',
			'applications',
			'certificates',
			'invoices',
			'company',
			'contacts',
			'quotations',
			'edit-profile',
			'assessments-listing',
			'assessor-listing',
			'change-password',
			'gp-failed-transactions',
			'payment-listing',
		);

		$menuSlug = 'sidebar-logged-in-primary';
		$type = 'page';
		$createMenuObj = new CreateMenuOption();

		foreach ( $sidebarPages as $menu_item ) {
			$createMenuObj->delete_nav_menu_item( $menuSlug, $menu_item, $type );
		}
		sleep( 2 );

		$createMenuObj = new CreateMenuOption();

		$menuSlug = 'sidebar-logged-in-primary';
		$createMenuObj->get_nav_menu_items( $menuSlug );


		$sidebarPages = array(
			'dashboard' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Dashboard',
					'page_post_name' => 'user-dashboard',
					'menu_order' => 1,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array('contact', 'biling', 'modified', 'legal', 'technical', 'staff', 'assessor' ),
				'classes' => array( 'menu-my-dashboard' ),
			),
			'ias-document' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'IAS Documents',
					'page_post_name' => 'ias-documents',
					'menu_order' => 2,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'staff', 'assessor', 'contact' ),
				'classes' => array( 'menu-my-iasdocument' ),
			),
			'applications' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'New Applications',
					'page_post_name' => 'applications',
					'menu_order' => 3,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'staff' ),
				'classes' => array( 'menu-my-application' ),
			),
			'certificates' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Certificates',
					'page_post_name' => 'certificates',
					'menu_order' => 4,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array('contact', 'biling', 'modified', 'legal', 'technical', 'staff' ),
				'classes' => array( 'menu-my-certificates' ),
			),
			'invoices' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Invoices',
					'page_post_name' => 'invoices',
					'menu_order' => 5,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'contact', 'biling', 'modified', 'legal', 'technical', 'staff' ),
				'classes' => array( 'menu-my-invoices' ),
			),
			'quotations' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Quotations',
					'page_post_name' => 'quotations',
					'menu_order' => 6,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'contact', 'biling', 'modified', 'legal', 'technical', 'staff', ),
				'classes' => array( 'menu-my-quotations' ),
			),
			'assessor-listing' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Assessors',
					'page_post_name' => 'assessor-listing',
					'menu_order' => 7,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'staff','assessor' ),
				'classes' => array( 'menu-my-assessor' ),
			),
			'assessments-listing' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Assessments',
					'page_post_name' => 'assessments-listing',
					'menu_order' => 8,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'staff', 'assessor' ),
				'classes' => array( 'menu-my-assessment' ),
			),
			'payment-listing' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Payment Listing',
					'page_post_name' => 'payment-listing',
					'menu_order' => 9,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'staff' ),
				'classes' => array( 'menu-my-paymentlist' ),
			),
			'edit-profile' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'My Profile',
					'page_post_name' => 'edit-profile',
					'menu_order' => 10,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'contact', 'biling', 'modified', 'legal', 'technical', 'staff', 'assessor' ),
				'classes' => array( 'menu-my-editprofile' ),
			),
			'change-password' => array(
				'menu_slug' => $menuSlug,
				'menu_option' => array(
					'title' => 'Change Password',
					'page_post_name' => 'change-password',
					'menu_order' => 11,
					'type' => 'page'
				),
				'all_logged_in_roles' => 'in',
				'user_roles' => array( 'contact', 'biling', 'modified', 'legal', 'technical' ),
				'classes' => array( 'menu-change-password' ),
			),
		);

		foreach ( $sidebarPages as $pagemenu ) {
			$createMenuObj->register_my_menu( $pagemenu );
			$createMenuObj->update_logged_in_roles( $pagemenu['user_roles'], $pagemenu['menu_slug'], $update_roles = true, $pagemenu['menu_option']['page_post_name'], $pagemenu['menu_option']['type'] );
		}

		$term = term_exists( 'sidebar-logged-in-primary', 'nav_menu' );
		$var = get_option( 'theme_mods_responsive' );
		$var['nav_menu_locations']['sidebar-logged-in-primary'] = $term['term_taxonomy_id'];
		update_option( 'theme_mods_responsive', $var );
    
    }

    /**
     * Migrate Down.
     */
    public function down() {

        $sidebarPages = array(
            'user-dashboard',
            'ias-documents',
            'applications',
            'certificates',
            'invoices',
            'company',
            'contacts',
            'quotations',
            'edit-profile',
            'change-password',
            'gp-failed-transactions',
            'payment-listing',
        );

        $menuSlug = 'sidebar-logged-in-primary';
        $type = 'page';
        $createMenuObj = new CreateMenuOption();

        foreach ($sidebarPages as $menu_item) {
            $createMenuObj->delete_nav_menu_item($menuSlug, $menu_item, $type);
        }
 
}